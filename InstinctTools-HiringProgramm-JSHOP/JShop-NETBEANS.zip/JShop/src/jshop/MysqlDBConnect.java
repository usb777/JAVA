/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package jshop;

/**
 *
 * @author IntD
 */
import java.io.*;
import java.net.*;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class MysqlDBConnect
{
   
    Connection conn=null;
                    
    String hostname = "localhost"; 
     String port = "3306"; 
     String dbname = "sha"; 
     String user = "root"; 
     String password = ""; 
    
   
      Statement stmt = null;
      ResultSet rs = null;
  String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname; 
        static void register_DB()
    { // register of Database 
          
          
          try 
           { // DriverManager.registerDriver(new com.mysql.jdbc.Driver());
       
           	Class.forName("com.mysql.jdbc.Driver").newInstance(); 
           } 
           catch (Exception e) 
           { 
                System.err.println("Unable to load driver."); 
                e.printStackTrace(); 
           } 
   
    }
    
    
     void connectDb(String hostname,String port,String dbname,String user,String password)
    {
             try 
           { 
        	 //  System.out.println("* Establish a connection"); 
        	 
                   conn = DriverManager.getConnection(url, user, password);  
           } 
           catch (SQLException sqle)
           { 
	            System.out.println("SQLException: " + sqle.getMessage()); 
	            System.out.println("SQLState: " + sqle.getSQLState()); 
	            System.out.println("VendorError: " + sqle.getErrorCode()); 
	            sqle.printStackTrace();
	            System.exit(1);
	   }
    }
     
 public static void main(String args[])
    {
     } // main   
         
  int GetDbRowcount(String tname)
  {
       int i=1;
       try {
         Connection conn = DriverManager.getConnection(url, user, password);  
         Statement st = conn.createStatement();;
         ResultSet rs = st.executeQuery("select * from "+tname);   
    
      ResultSetMetaData rsmd = rs.getMetaData();
      int n=rsmd.getColumnCount();
   
  rs.first();  
    while(rs.next())
        { i++;     
        }  
  rs.first();
  rs.close();
   st.close();
   conn.close();
     
     }catch (Exception e) 
       {System.err.println(e);
     }
    
       return i;
  }    
 void GetData()
 {
     
        try { 
            Class.forName("com.mysql.jdbc.Driver"); 
         
           
            Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
            Statement st = con.createStatement(); 
            ResultSet rs = st.executeQuery("select * from ---"); 
           
  
           rs.first();
             while(rs.next())
           { 
           }
                            
               
        } catch (SQLException e)
           { 
            e.printStackTrace(); 
             } 
           catch (ClassNotFoundException e)
              { 
               e.printStackTrace(); 
               }  // end of the block 
        
 
 }        
   
     
}       