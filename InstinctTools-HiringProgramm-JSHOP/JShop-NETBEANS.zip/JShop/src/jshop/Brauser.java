/*
 * Brauser.java
 *
 * Created on 5 Ноябрь 2008 г., 9:26
 */

package jshop;

/**
 *
 * @author  IntD
 */
import java.sql.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.ListModel.*;
import java.awt.*;

public class Brauser extends javax.swing.JFrame
{
    
    Connection conn=null;
  /** Variables used in programm   */   
    String TG_ID;
    private String tgoods_query="select * from type_goods order by tg_name ";                
    private String goods_query="select * from goods order by g_name ";                
  /** Variables used in programm   */   
   
    String hostname = "localhost"; 
      String port = "3306"; 
      String dbname = "sha"; 
      String user = "root"; 
      String password = "";   
      Statement stmt = null;
      ResultSet rs = null;
      String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname; 
   
  
  public String getTG_ID()
    {
      return TG_ID;
    }
  public void setTG_ID(String tg_id1)
    {
     TG_ID=tg_id1;
    }
  
   
  public DefaultListModel dlm(String tgid)
  {
   DefaultListModel dlistm=new DefaultListModel();
   dlistm.removeAllElements();
    try { 
            Class.forName("com.mysql.jdbc.Driver"); 
         
           
            Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
            Statement st = con.createStatement(); 
            ResultSet rs = st.executeQuery("select g_name from goods where tg_id='"+tgid+"'"); 
           
  
           rs.first();
           dlistm.addElement(rs.getString("g_name"));
             while(rs.next())
           { 
                 dlistm.addElement(rs.getString("g_name"));
           }
                            
               
        } catch (SQLException e)
           { 
            e.printStackTrace(); 
            System.out.println("DLM="+e);
             } 
           catch (ClassNotFoundException e)
              { 
               e.printStackTrace();
               System.out.println("DLM1="+e);
               }  // end of the block 
   
   return dlistm;
  
  }      
  
  
  public void setTFieldParameter(String listpar)
  {
   
         try { 
            Class.forName("com.mysql.jdbc.Driver"); 
                  
            Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
            Statement st = con.createStatement(); 
            ResultSet rs = st.executeQuery("select * from goods where g_name='"+listpar+"'"); 
           rs.first();
            this.setTG_ID(rs.getString("tg_id"));
                
            jTextField1.setText(rs.getString("g_price"));
            jTextField2.setText(rs.getString("g_country"));
            jTextArea1.setText(rs.getString("g_desc"));
            
            
            rs.close();
            st.close();
           con.close();
           
        } catch (SQLException e)
           { 
             e.printStackTrace();
             System.out.println("SetFP="+e);
             
           } 
           catch (ClassNotFoundException e)
              { 
               e.printStackTrace(); 
                      System.out.println("SetFP1="+e);
      
               }  // end of the block 
  
  }      
      
      
    /** Creates new form Brauser */
    public Brauser()
    {
        initComponents();
      //  jCB1.addItem("1");
        
          try { 
            Class.forName("com.mysql.jdbc.Driver"); 
         
           
            Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
            Statement st = con.createStatement(); 
            ResultSet rstg = st.executeQuery(tgoods_query); 
    //        ResultSet rsg = st.executeQuery(goods_query); 
            
   // jTable1.changeSelection(0, 1, false, false);
          jCB1.removeAllItems();
            rstg.first();
            jCB1.addItem(rstg.getString("tg_name"));
            this.setTG_ID(rstg.getString("tg_id"));
           //System.out.println(this.getTG_ID());
          while(rstg.next())
           { jCB1.addItem(rstg.getString("tg_name"));
           }
        
          
                 
                  
        } catch (SQLException e)
           { 
            e.printStackTrace();
            System.out.println("Brauser constructor"+e);
     
             } 
           catch (ClassNotFoundException e)
              { 
               e.printStackTrace();
                 System.out.println("Brauser constructor1"+e);
     
               }  // end of the block 
       Toolkit tk = Toolkit.getDefaultToolkit(); 
      Dimension dim = tk.getScreenSize();  // Get dimension of Screen 
      int wx= (int)dim.getWidth();  
      int hy=(int)dim.getHeight();
 
       
      this.setLocation(wx/4, hy/4);
      this.setVisible(true);
    }
    
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jCB1 = new javax.swing.JComboBox();
        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList();
        jTextField1 = new javax.swing.JTextField();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jTextField2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setTitle("Brauser of goods (Brotherhood of steel)");
        setBackground(new java.awt.Color(153, 51, 255));
        setResizable(false);

        jCB1.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                jCB1ItemStateChanged(evt);
            }
        });

        jList1.addListSelectionListener(new javax.swing.event.ListSelectionListener() {
            public void valueChanged(javax.swing.event.ListSelectionEvent evt) {
                jList1ValueChanged(evt);
            }
        });
        jScrollPane1.setViewportView(jList1);

        jButton1.setText("Exit");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                exit(evt);
            }
        });

        jLabel1.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel1.setText("Please, chose category");

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel2.setText("Select goods");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel3.setText("Price $");

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel4.setText("Country");

        jTextArea1.setColumns(20);
        jTextArea1.setRows(5);
        jScrollPane2.setViewportView(jTextArea1);

        jLabel5.setFont(new java.awt.Font("Times New Roman", 1, 12));
        jLabel5.setText("Description");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addGap(63, 63, 63))
                            .addComponent(jCB1, 0, 175, Short.MAX_VALUE)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, 175, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(jLabel4)
                                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(jLabel3, javax.swing.GroupLayout.Alignment.LEADING))
                                .addGap(15, 15, 15))
                            .addComponent(jScrollPane2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addComponent(jLabel5)
                                .addGap(58, 58, 58))))
                    .addComponent(jButton1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 87, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jCB1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(6, 6, 6)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jLabel4))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jLabel5)
                        .addGap(8, 8, 8)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.DEFAULT_SIZE, 139, Short.MAX_VALUE))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 187, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addGap(12, 12, 12))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exit(java.awt.event.ActionEvent evt)//GEN-FIRST:event_exit
    {//GEN-HEADEREND:event_exit
        // TODO add your handling code here:
        dispose();
    }//GEN-LAST:event_exit

    private void jCB1ItemStateChanged(java.awt.event.ItemEvent evt)//GEN-FIRST:event_jCB1ItemStateChanged
    {//GEN-HEADEREND:event_jCB1ItemStateChanged
        // TODO add your handling code here:
       // System.out .println(jCB1.getSelectedItem());
        
        try { 
            Class.forName("com.mysql.jdbc.Driver"); 
                  
            Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
            Statement sttd = con.createStatement(); 
            ResultSet rstd = sttd.executeQuery("select tg_id from type_goods where tg_name='"+jCB1.getSelectedItem()+"'"); 
           rstd.first();
            setTG_ID(rstd.getString("tg_id"));
         
         
            rstd.close();
            sttd.close();
           con.close();
           
        } catch (SQLException e)
           { 
             e.printStackTrace();
             
           } 
           catch (ClassNotFoundException e)
              { 
               e.printStackTrace(); 
               
               }  // end of the block 
         
      try
       { 
          jList1.setModel(dlm(this.getTG_ID())); 
          jList1.setSelectedIndex(0);
       }catch(Exception e)
          {System.out.println("Brauser of goods get an error:"+e);
            JOptionPane.showMessageDialog( null, "Sorry! But this category is empty", "Empty Category", JOptionPane.INFORMATION_MESSAGE);
          }
      
    }//GEN-LAST:event_jCB1ItemStateChanged

    private void jList1ValueChanged(javax.swing.event.ListSelectionEvent evt)//GEN-FIRST:event_jList1ValueChanged
    {//GEN-HEADEREND:event_jList1ValueChanged
        // TODO add your handling code here:
     // Generate an Error
      try{  
          String par=String.valueOf(jList1.getSelectedValue()).toString();
        setTFieldParameter(par);
      }catch(Exception e)
         {System.out.println("JLIST Value Change"+e);}
    }//GEN-LAST:event_jList1ValueChanged
    
    /**
     * @param args the command line arguments
     */
    public static void main(String args[])
    {
        java.awt.EventQueue.invokeLater(new Runnable()
        {
            public void run()
            {
                new Brauser().setVisible(true);
            }
        });
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JComboBox jCB1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    public javax.swing.JList jList1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextField jTextField1;
    private javax.swing.JTextField jTextField2;
    // End of variables declaration//GEN-END:variables
    
}
