/*
 * JShop.java
 *
 * Created on 3 Октябрь 2008 г., 9:40
 */
/*
 
 Set & Get for OOP s74

 */
package jshop;

/**
 *
 * @author  UnknownSoldier
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.tree.*;
import javax.swing.*;
import javax.swing.event.*;



import java.io.*;
import java.net.*;

import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.*;
import javax.swing.table.*;

import jshop.AdminShop;
import jshop.Brauser.*;




class DetailsShop extends Frame
{    JTextField jTF1;
     JTextField jTF2;
     JTextField jTF3;
     JTextField jTF4;        
     TextArea tA;
    
   public DetailsShop()
    {setLayout(null);
     setBackground(new Color(205, 155, 255));
     setForeground(new Color(0, 0, 255)); 
       
      setBounds(500/*x*/,300/*y*/,500/*w*/,280/*h*/);  
      setTitle("Details Module");
       setVisible(true);
   
     addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
              dispose();
            }
        });   // addWindowListener closing
    int y=0;
      JLabel jL1=new JLabel("Type of Goods");
      jL1.setBounds(10,30+y,100,15);
      this.add(jL1);
     
      jTF1=new JTextField("");
      jTF1.setBounds(10, 50+y, 150, 25);
      this.add(jTF1);
     
      JLabel jL2=new JLabel("Name of Goods");
      jL2.setBounds(10,90+y,100,15);
      this.add(jL2);
     
      jTF2=new JTextField("");
      jTF2.setBounds(10, 110+y, 150, 25);
      this.add(jTF2);
     
      JLabel jL3=new JLabel("Price");
      jL3.setBounds(10,150+y,100,15);
      this.add(jL3);
     
      jTF3=new JTextField("");
      jTF3.setBounds(10, 170+y, 150, 25);
      this.add(jTF3);
      
      JLabel jL4=new JLabel("Country-manufacturer");
      jL4.setBounds(10,210+y,140,15);
      this.add(jL4);
     
      jTF4=new JTextField("");
      jTF4.setBounds(10, 230+y, 150, 25);
      this.add(jTF4);
      
      JLabel jL5=new JLabel("Description");
      jL5.setBounds(200,30+y,100,15);
      this.add(jL5);      
      
   
      tA=new TextArea("");
      tA.setBounds(200, 50+y, 270, 150);;
      
      this.add(tA);
      
      JButton jB1=new JButton("Exit");
      jB1.setBounds(400, 230, 70, 25);
      this.add(jB1);
      
      jB1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jB1ActionPerformed(evt);
            }
        });
      
      
      
      
    } // end AdminShop creater 
   
public void setALLText(String t1,String t2,String t3,String t4,String tb)
{   jTF1.setText(t1);
    jTF2.setText(t2);
    jTF3.setText(t3);
    jTF4.setText(t4);
    tA.setText(tb);
}     

   
  
   
private void NewLabel(JLabel jl,String lCaption,int x,int y, int height,int weight)
 {
      jl=new JLabel(lCaption);
      jl.setBounds(x,y,height,weight);
      this.add(jl);  
     
 }

private void jB1ActionPerformed(java.awt.event.ActionEvent evt)                                         
    {                                             
        // TODO add your handling code here:
      dispose();// DetailsShop ds=new DetailsShop();
    }                                        
    
    
      
} // End class DetailsShop




public class JShop extends Frame implements TreeSelectionListener
{ Connection conn = null;   
     String hostname = "localhost"; 
     String port = "3306"; 
     String dbname = "sha"; 
     String user = "root"; 
     String password = ""; 
     private String url = "jdbc:mysql://"+hostname+":"+port+"/"+dbname;
     
     private String acount="user";
     
      Statement stmt = null;
      ResultSet rs = null;
    
    
       
        
       
       private Vector results; 
      private Vector results1; 
        private Hashtable tabl=new Hashtable();
      
        private JTree tree;
      private String treeSelectText;  
        
        
    
    /** Creates new form JShop */
      
      
      
    public JShop() //extends JFrame implements TreeSelectionListener
    {
     //   
      //  private JTextField currentSelectionField;  
        initComponents();
      Toolkit tk = Toolkit.getDefaultToolkit(); 
      Dimension dim = tk.getScreenSize(); 
   
   int wx= (int)dim.getWidth();
   int hy=(int)dim.getHeight();
     
       setBounds(wx/4,hy/4,400,400); 
       setTitle("Shop Admin v. 0001 (Saver of costumers good)");
     
       addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
              System.exit(0);
            }
        });   // addWindowListener closing  ;
        
                      
         
     jLabel1.setText("None");
             // TREE   
        
     DefaultMutableTreeNode root = new DefaultMutableTreeNode("Goods for sale with category");
     
    try {
         Class.forName("com.mysql.jdbc.Driver"); 
         Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
           
        
         Statement st = con.createStatement();
         Statement stg = con.createStatement();
         
         ResultSet rs = st.executeQuery("select tg_id,tg_name from type_goods");   
         ResultSet rs_tg = st.executeQuery("select tg_id,tg_name from type_goods order by tg_id");   
         ResultSet rs_g = stg.executeQuery("select tg_id,g_name from goods  order by tg_id");   
         

        DefaultMutableTreeNode child3;
        DefaultMutableTreeNode child33;
       
         DatabaseTableModel model_tg = new DatabaseTableModel(); 
         model_tg.setDataSource(rs_tg);
        
         rs_tg.close();
         st.close();
         
         DatabaseTableModel model_g = new DatabaseTableModel(); 
         model_g.setDataSource(rs_g);
               
         rs_g.close();
         st.close();
         
         for(int i=0;i<=model_tg.getRowCount()-1;i++)
           {  child3 = new DefaultMutableTreeNode(model_tg.getValueAt(i, 1));
              root.add(child3);
             for(int j=0;j<=model_g.getRowCount()-1;j++)
              {  
                if (String.valueOf(model_g.getValueAt(j, 0)).equals(String.valueOf(model_tg.getValueAt(i, 0))))
                  {
                      child33 = new DefaultMutableTreeNode(model_g.getValueAt(j, 1));
                      child3.add(child33); //child33.removeAllChildren();
                     }  //if
                
              } //for J  
           }  // for I
 
        rs.close();
        st.close();
        con.close();
     
     } catch (SQLException e)
           { 
            e.printStackTrace(); 
             } 
           catch (ClassNotFoundException e)
              { 
               e.printStackTrace(); 
               }   
        tree=new JTree(root);
        tree.addTreeSelectionListener(this);
      //  tree.setBounds(100, 100, 200,   200);
       // this.add(tree);
        jScrollPane1.add(tree);   
        jScrollPane1.setViewportView(tree);  
           
      // TREE
           
           
          // String[] s;
          
    }// JSHOP()
   
    public void valueChanged(TreeSelectionEvent event)
    {
     Object selection=tree.getLastSelectedPathComponent();
     if (selection!=null)
       { 
        // currentSelectionField.setText("");
         jLabel1.setText(selection.toString());
         treeSelectText=selection.toString();
       }
  //   System.out.println(jLabel1.getText());
    }    
  //  */
    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents()
    {

        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTree1 = new javax.swing.JTree();
        jLabel2 = new javax.swing.JLabel();
        menuBar1 = new java.awt.MenuBar();
        menu1 = new java.awt.Menu();
        menuItem1 = new java.awt.MenuItem();
        menuItem2 = new java.awt.MenuItem();
        menuItem3 = new java.awt.MenuItem();
        menu2 = new java.awt.Menu();
        menu_dgoods = new java.awt.MenuItem();
        menu_type_goods = new java.awt.MenuItem();
        menu3 = new java.awt.Menu();
        menuItem6 = new java.awt.MenuItem();

        setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addWindowListener(new java.awt.event.WindowAdapter()
        {
            public void windowClosing(java.awt.event.WindowEvent evt)
            {
                exitForm(evt);
            }
        });

        jButton1.setText("Details >>");
        jButton1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                jButton1ActionPerformed(evt);
            }
        });

        jLabel1.setText("jLabel1");

        jScrollPane1.setAutoscrolls(true);
        jScrollPane1.setViewportView(jTree1);

        jLabel2.setFont(new java.awt.Font("Times New Roman", 1, 14));
        jLabel2.setText("Simple Tree of all categories and  goods ");

        menu1.setActionCommand("Menu");
        menu1.setLabel("File");
        menu1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                file_exit(evt);
            }
        });

        menuItem1.setLabel("Admin mode");
        menuItem1.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                file_admin(evt);
            }
        });
        menu1.add(menuItem1);

        menuItem2.setLabel("Brauser");
        menuItem2.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menuItem2ActionPerformed(evt);
            }
        });
        menu1.add(menuItem2);
        menu1.addSeparator();
        menuItem3.setLabel("Exit");
        menuItem3.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menuItem3ActionPerformed(evt);
            }
        });
        menu1.add(menuItem3);

        menuBar1.add(menu1);

        menu2.setLabel("Dictionery");

        menu_dgoods.setLabel("Cataloge of goods");
        menu_dgoods.setName("menu_goods");
        menu_dgoods.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menu_dgoodsActionPerformed(evt);
            }
        });
        menu2.add(menu_dgoods);

        menu_type_goods.setLabel("Cataloge of categories");
        menu_type_goods.setName("menu_type_goods");
        menu_type_goods.addActionListener(new java.awt.event.ActionListener()
        {
            public void actionPerformed(java.awt.event.ActionEvent evt)
            {
                menu_type_goodsActionPerformed(evt);
            }
        });
        menu2.add(menu_type_goods);

        menuBar1.add(menu2);

        menu3.setLabel("Help");

        menuItem6.setLabel("About me");
        menu3.add(menuItem6);

        menuBar1.add(menu3);

        setMenuBar(menuBar1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 219, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(74, 74, 74)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(143, 143, 143)
                        .addComponent(jButton1)))
                .addContainerGap(57, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 264, Short.MAX_VALUE)
                .addGap(18, 18, 18)
                .addComponent(jButton1)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        
    /** Exit the Application */
    private void exitForm(java.awt.event.WindowEvent evt)//GEN-FIRST:event_exitForm
    {
        System.exit(0);
    }//GEN-LAST:event_exitForm

    private void file_exit(java.awt.event.ActionEvent evt)//GEN-FIRST:event_file_exit
    {//GEN-HEADEREND:event_file_exit
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_file_exit

    private void file_admin(java.awt.event.ActionEvent evt)//GEN-FIRST:event_file_admin
    {//GEN-HEADEREND:event_file_admin
        // TODO add your handling code here:
       //   AdminShop ash=new AdminShop();
      //  menuItem1.setLabel("1");
  String str =JOptionPane.showInputDialog("Please input a password!");

        if (str.equals("1"))
        {
        AdminShop as=new AdminShop();
        as.jTable1.changeSelection(0, 1, false, false);
        }
        else
        {  
           JOptionPane.showMessageDialog(null,"Wrong password!","Error!", JOptionPane.ERROR_MESSAGE);

        }
        
    }//GEN-LAST:event_file_admin

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_jButton1ActionPerformed
    {//GEN-HEADEREND:event_jButton1ActionPerformed
        // TODO add your handling code here:
   
String tp1="";
String tp2="";
String tp3="";
String tp4="";
String tp5="";

        DetailsShop ds=new DetailsShop();
       
      
   
         try {
             
          Class.forName("com.mysql.jdbc.Driver"); 
          Connection con = DriverManager.getConnection("jdbc:mysql://"+hostname+":"+port+"/"+dbname, user, password); 
          Statement st = con.createStatement();     
             
         ResultSet rs = st.executeQuery("select * from goods where g_name='"+treeSelectText+"'");   
        rs.first();
         tp2=rs.getString("g_name");
         tp3=rs.getString("g_price");
         tp4=rs.getString("g_country");
         tp5=rs.getString("g_desc");
        
         ResultSet rsg = st.executeQuery("select * from type_goods where tg_id="+rs.getString("tg_id"));   
         rsg.first();
         tp1=rsg.getString("tg_name");
    
  rs.close();
   st.close();
   con.close();
       ds.setALLText(tp1,tp2,tp3,tp4,tp5);
    
     }catch (SQLException e) 
       { 
         System.err.println("Details form error:"+e);
       // ds.close();
         ds.dispose();
         JOptionPane.showMessageDialog(null,"Please! Select goods from category","Warning!!!",JOptionPane.WARNING_MESSAGE);
        } // try
        catch (ClassNotFoundException e)
              { 
               e.printStackTrace(); 
               }  // end of the block 
       
       
       
       
       
    }//GEN-LAST:event_jButton1ActionPerformed

    private void menuItem2ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menuItem2ActionPerformed
    {//GEN-HEADEREND:event_menuItem2ActionPerformed
        // TODO add your handling code here: 
        System.out.println("Brauser");
        Brauser br=new Brauser();
        
    }//GEN-LAST:event_menuItem2ActionPerformed

    private void menuItem3ActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menuItem3ActionPerformed
    {//GEN-HEADEREND:event_menuItem3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_menuItem3ActionPerformed

    private void menu_type_goodsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menu_type_goodsActionPerformed
    {//GEN-HEADEREND:event_menu_type_goodsActionPerformed
        // TODO add your handling code here:
        DictCategory dc=new DictCategory();
        dc.jButton6.setEnabled(false);
        dc.jTable1.changeSelection(0, 1, false, false); // Set index in first record in table
        dc.MinSize();
     if (acount.equals("admin"))
      {
        dc.jButton1.setEnabled(true);
        dc.jButton2.setEnabled(true);
        dc.jButton3.setEnabled(true);
      }
    else 
     {
      dc.jButton1.setEnabled(false);
      dc.jButton2.setEnabled(false);
      dc.jButton3.setEnabled(false);
     }
        
}//GEN-LAST:event_menu_type_goodsActionPerformed

    private void menu_dgoodsActionPerformed(java.awt.event.ActionEvent evt)//GEN-FIRST:event_menu_dgoodsActionPerformed
    {//GEN-HEADEREND:event_menu_dgoodsActionPerformed
        // TODO add your handling code here:
      AdminShop as=new AdminShop();
       as.jTable1.changeSelection(0, 1, false, false); // Set index in first record in table
      as.MinSize();
if (acount.equals("admin"))
  {
   as.jButton1.setEnabled(true);
   as.jButton2.setEnabled(true);
   as.jButton3.setEnabled(true);
  }
else//GEN-LAST:event_menu_dgoodsActionPerformed
     {
          as.jButton1.setEnabled(false);
            as.jButton2.setEnabled(false);
             as.jButton3.setEnabled(false);
   
     }
}
    
    /**
     * @param args the command line arguments
     */
   
 
    public static void main(String args[])
    {
        
     Object[] possibleValues={"Admin", "User" };

  Object selectedValue =JOptionPane.showInputDialog(null,"Select your account", "Choose", JOptionPane.INFORMATION_MESSAGE,  null, possibleValues, possibleValues[1]);

         // possibleValues[1] - элемент для фокуса

         // второй null – иконка по умолчанию

         if (selectedValue.equals("Admin")) 

         {  
               String str =JOptionPane.showInputDialog("Please input a password!");
//System.out.println("You enter"+str);
        if (str.equals("1"))
          {  
                 java.awt.EventQueue.invokeLater(new Runnable()
              {  public void run()
                {  JShop js=new JShop();
                   js.setVisible(true);
                   
                    js.acount="admin";
     
                }
              });
        
          }
        else
         {  
                   JOptionPane.showMessageDialog(null,"Wrong password! You will enter the program as user ","Error!", JOptionPane.INFORMATION_MESSAGE);
                  java.awt.EventQueue.invokeLater(new Runnable()
              {  public void run()
                {
                     JShop js=new JShop();
                   js.setVisible(true);
                   js.acount="user";
     
                }
              });  
         }       
         
         }  
         else
         {
              java.awt.EventQueue.invokeLater(new Runnable()
              {  public void run()
                {
                     JShop js=new JShop();
                   js.setVisible(true);
                   js.acount="user";
     
                }
              });
      
         
         }
        
        
        
        
        
        
        
       
        
     
    } // main   
        
    
     

   

           
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTree jTree1;
    private java.awt.Menu menu1;
    private java.awt.Menu menu2;
    private java.awt.Menu menu3;
    private java.awt.MenuBar menuBar1;
    private java.awt.MenuItem menuItem1;
    private java.awt.MenuItem menuItem2;
    private java.awt.MenuItem menuItem3;
    private java.awt.MenuItem menuItem6;
    private java.awt.MenuItem menu_dgoods;
    private java.awt.MenuItem menu_type_goods;
    // End of variables declaration//GEN-END:variables
    
}
