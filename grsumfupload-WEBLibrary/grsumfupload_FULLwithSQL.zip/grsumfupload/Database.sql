/*
SQLyog Ultimate v9.50 
MySQL - 5.5.16 : Database - db_grsumf
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`db_grsumf` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `db_grsumf`;

/*Table structure for table `brain_storage` */

DROP TABLE IF EXISTS `brain_storage`;

CREATE TABLE `brain_storage` (
  `bs_id` int(11) NOT NULL AUTO_INCREMENT,
  `s_id` int(11) DEFAULT NULL,
  `bs_url` varchar(250) DEFAULT NULL,
  `bs_name` varchar(250) DEFAULT NULL,
  `bs_description` text,
  `bs_year` varchar(20) DEFAULT NULL,
  `bs_filename` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`bs_id`),
  KEY `s_id` (`s_id`),
  CONSTRAINT `brain_storage_ibfk_1` FOREIGN KEY (`s_id`) REFERENCES `sotrudniki` (`s_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;

/*Data for the table `brain_storage` */

insert  into `brain_storage`(`bs_id`,`s_id`,`bs_url`,`bs_name`,`bs_description`,`bs_year`,`bs_filename`) values (13,1,'C:UsersUnknownSoldierworkspace.metadata.pluginsorg.eclipse.wst.server.core	mp0wtpwebappsgrsumfuploadAllUsersDocskaztDiferencials.doc','Дифференorциалы','Дифференциалы и в Африке Дифференциалыr','2016','Diferencials.doc'),(18,43,'C:UsersUnknownSoldierworkspace.metadata.pluginsorg.eclipse.wst.server.core	mp0wtpwebappsgrsumfuploadAllUsersDocs\rodvFish Eggs.doc','Fish Eggs - икра сырная','Рыбья икра способствует! or','2010','Fish Eggs.doc'),(19,43,'C:UsersUnknownSoldierworkspace.metadata.pluginsorg.eclipse.wst.server.core	mp0wtpwebappsgrsumfuploadAllUsersDocs\rodv\resume_cook.docx','resumeCook - досье','Лваплдвоаполдв вапваповлдап','2016','resume_cook.docx'),(21,44,'C:UsersUnknownSoldierworkspace.metadata.pluginsorg.eclipse.wst.server.core	mp0wtpwebappsgrsumfuploadAllUsersDocs\rudlÐÐµÐºÑÐ¸Ñ_5_1.docx','Внутренние классы -5.1','Внутренним называется класс, определенный внутри другого класса.','2010','lec_5_1.docx'),(22,44,'C:UsersUnknownSoldierworkspace.metadata.pluginsorg.eclipse.wst.server.core	mp0wtpwebappsgrsumfuploadAllUsersDocs\rudlÐÐµÐºÑÐ¸Ñ_10.docx','JFC и orSWING -10','JFC и Swing. Компиляция и запуск Swing-программ. Примеры Swing-приложений. Компоненты Swing. Модели. Базовые классы для компонент Swing. Look and Feel. Изменение Look and Feel. Менеджеры размещения. BorderLayout. BoxLayout. CardLayout. FlowLayout. GridBagLayout. GridLayout. GroupLayout. SpringLayout. Абсолютное позиционирование.','2010','lec_10.docx');

/*Table structure for table `kafedra` */

DROP TABLE IF EXISTS `kafedra`;

CREATE TABLE `kafedra` (
  `k_id` smallint(6) NOT NULL AUTO_INCREMENT,
  `k_name` varchar(100) DEFAULT NULL,
  `k_cabinet` varchar(50) DEFAULT NULL,
  `k_email` varchar(100) DEFAULT NULL,
  `k_telefon1` varchar(100) DEFAULT NULL,
  `k_telefon2` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`k_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

/*Data for the table `kafedra` */

insert  into `kafedra`(`k_id`,`k_name`,`k_cabinet`,`k_email`,`k_telefon1`,`k_telefon2`) values (1,'Математического анализа, дифференциальных уравнений и алгебры','ауд. 309 и 221','kaf_matan@grsu.byy','+375-152-74-43-90','+375-152-44-45-36'),(2,'Системного программирования и компьютерной безопасности','ауд. 222','kaf_spkb@grsu.by','+375-152-72-13-92',NULL),(3,'Современных технологий программирования ','ауд. 212','ivt@grsu.by','+375-152-74-29-57',NULL),(4,'Стохастического анализа и эконометрического моделирования ','ауд. 312','kaf_stohan@grsu.by','+375 -152-73-39-599',NULL),(5,'Фундаментальной и прикладной математики','ауд. 314','kaf_teorfun@grsu.by','+375-152-74-06-73',NULL);

/*Table structure for table `sotrudniki` */

DROP TABLE IF EXISTS `sotrudniki`;

CREATE TABLE `sotrudniki` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT,
  `k_id` smallint(6) DEFAULT NULL,
  `s_fio` varchar(200) DEFAULT NULL,
  `s_rank` varchar(40) DEFAULT NULL,
  `s_degree` varchar(60) DEFAULT NULL,
  `s_position` varchar(40) DEFAULT NULL,
  `s_email` varchar(100) DEFAULT NULL,
  `s_telefon` varchar(100) DEFAULT NULL,
  `s_login` varchar(100) DEFAULT NULL,
  `s_password` varchar(100) DEFAULT NULL,
  `s_role` smallint(6) DEFAULT NULL,
  PRIMARY KEY (`s_id`),
  KEY `sotrudniki_ibfk_1` (`k_id`),
  CONSTRAINT `sotrudniki_ibfk_1` FOREIGN KEY (`k_id`) REFERENCES `kafedra` (`k_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8;

/*Data for the table `sotrudniki` */

insert  into `sotrudniki`(`s_id`,`k_id`,`s_fio`,`s_rank`,`s_degree`,`s_position`,`s_email`,`s_telefon`,`s_login`,`s_password`,`s_role`) values (1,1,'Андреева Татьяна Казимировна','доцент','кандидат физико-математических наук','1','2','3','andreeva','123',2),(2,5,'Ванькова Татьяна Николаевна','доцент','кандидат физико-математических наук','net','vank@gmai.com','777-33-222','vankova','vanvan',2),(3,1,'Горбузов  Виктор Николаевич','профессор','кандидат физико-математических наук','','','','gorv','gor3',2),(4,1,'Гринь Александр Александрович','доцент','кандидат физико-математических наук','заведующий кафедрой',NULL,NULL,'grin','grin100',2),(5,1,'Детченя Людмила Викторовна','доцент','кандидат физико-математических наук','net','null','null','detl','det4',2),(6,1,'Касперко Мира Владимировна','старший преподаватель',NULL,NULL,NULL,NULL,'kasm','kas5',2),(7,1,'Костюкович Михаил Евгеньевич','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'kosm','kos6',2),(8,1,'Мартынов Иван Платонович','профессор','доктор физико-математических наук',NULL,NULL,NULL,'mari','mar7',2),(9,1,'Метлицкий Александр Николаевич','старший преподаватель',NULL,NULL,NULL,NULL,'meta','met8',2),(10,1,'Немец Владимир Стефанович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'nemv','nem9',2),(11,1,'Павлючик Павел Болеславович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'pavp','pav10',2),(12,1,'Пецевич Виктор Михайлович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'pecv','pec11',2),(13,1,'Проневич Павел Францевич','старший преподаватель',NULL,NULL,NULL,NULL,'pronp','pron12',2),(14,1,'Пронько Вячеслав Аркадьевич','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'pronv','pron13',2),(15,1,'Просвирнина Ирина Борисовна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'prosi','pros14',2),(16,1,'Трифонова Ирина Владимировна','старший преподаватель',NULL,NULL,NULL,NULL,'trifi','trif15',2),(17,1,'Тыщенко Валентин Юрьевич','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'tyshv','tysh16',2),(18,2,'Ващило Владимир Витольдович','старший преподаватель',NULL,NULL,NULL,NULL,'vashv','vash17',2),(19,2,'Выдра Кристина Станиславовна','старший преподаватель',NULL,NULL,NULL,NULL,'vydk','vyd18',2),(20,2,'Дирвук Евгений Владимирович','старший преподаватель',NULL,NULL,NULL,NULL,'dire','dir19',2),(21,2,'Доронин Алексей Константинович','преподаватель-стажер',NULL,NULL,NULL,NULL,'dora','dor20',2),(22,2,'Еремина Александра Рафаэловна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'erea','ere21',2),(23,2,'Зайкова Светлана Алексеевна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'zajs','zaj21',2),(24,2,'Кадан Александр Михайлович','доцент','кандидат технических наук','заведующий кафедрой',NULL,NULL,'kada','kad22',2),(25,2,'Ливак Елена Николаевна','доцент','кандидат технических наук',NULL,NULL,NULL,'live','liv23',2),(26,2,'Липницкий Валерий Анатольевич','профессор','доктор технических наук',NULL,NULL,NULL,'lipv','lip24',2),(27,2,'Сазонова Анна Тадэушевна','старший преподаватель',NULL,NULL,NULL,NULL,'saza','saz25',2),(28,2,'Середа Елена Владимировна','преподаватель',NULL,NULL,NULL,NULL,'sere','ser26',2),(29,3,'Антоник Денис Владимирович','старший преподаватель',NULL,NULL,NULL,NULL,'antd','ant27',2),(30,3,'Вишневский Сергей Янович','преподаватель',NULL,NULL,NULL,NULL,'vishs','vish28',2),(31,3,'Гуща Юлия Вальдемаровна','старший преподаватель',NULL,NULL,NULL,NULL,'gysh','gush29',2),(32,3,'Домбровский Павел Эдуардович','преподаватель',NULL,NULL,NULL,NULL,'domp','dom30',2),(33,3,'Дорошкова Галина Юрьевна','преподаватель',NULL,NULL,NULL,NULL,'dorg','dor31',2),(34,3,'Жавнерко Евгений Викторович','старший преподаватель',NULL,NULL,NULL,NULL,'zhave','zhav32',2),(35,3,'Изосимова Татьяна Николаевна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'izost','izos33',2),(36,3,'Карканица Анна Викторовна','старший преподаватель',NULL,NULL,NULL,NULL,'kara','kar34',2),(37,3,'Курьян Николай Николаевич ','преподаватель',NULL,NULL,NULL,NULL,'kurn','kur35',2),(38,3,'Куц Александр Иванович','старший преподаватель',NULL,NULL,NULL,NULL,'kyca','kyc36',2),(39,3,'Лысюк Елена Сергеевна','старший преподаватель',NULL,NULL,NULL,NULL,'lyse','lys37',2),(40,3,'Макарова Нина Петровна ','доцент','кандидат педагогических наук',NULL,NULL,NULL,'makn','mak38',2),(41,3,'Олизарович Евгений Владимирович','доцент','кандидат технических наук',NULL,NULL,NULL,'olie','oli39',2),(42,3,'Рапчинская Елена Сергеевна','преподаватель',NULL,NULL,NULL,NULL,'rape','rap40',2),(43,3,'Родченко Вадим Григорьевич','доцент','кандидат технических наук','','','45645','rodv','rod41',2),(44,3,'Рудикова Лада Владимировна','доцент','кандидат физико-математических наук','заведующий кафедрой',NULL,NULL,'rudl','rud42',2),(45,3,'Скращук Владислав Сергеевич','старший преподаватель',NULL,NULL,NULL,NULL,'skrv','skr43',2),(46,3,'Хартовский Вадим Евгеньевич','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'harv','har44',2),(47,3,'Шушкевич Геннадий Чеславович ','профессор','доктор физико-математических наук',NULL,NULL,NULL,'shush','shush45',2),(48,4,'Китурко Ольга Михайловна',NULL,'кандидат физико-математических наук',NULL,NULL,NULL,'kito','kit46',2),(49,4,'Косарева Екатерина Владимировна',NULL,'кандидат физико-математических наук',NULL,NULL,NULL,'kose','kos47',2),(50,4,'Маталыцкий Михаил Алексеевич','профессор','кандидат физико-математических наук','заведующий кафедрой',NULL,NULL,'matm','mat48',2),(51,4,'Науменко Виктор Викторович','старший преподаватель',NULL,NULL,NULL,NULL,'nauv','nau49',2),(52,4,'Паньков Андрей Витальевич','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'pana','pan50',2),(53,4,'Русилко Татьяна Владимировна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'rust','rus51',2),(54,4,'Семенчук Наталья Владимировна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'semn','sem52',2),(55,4,'Статкевич Святослав Эдуардович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'stat','stat53',2),(56,5,'Березкина Наталия Серафимовна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'bern','ber54',2),(57,5,'Бойко Валерий Константинович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'bojv','boj55',2),(58,5,'Булгаков Валерий Иванович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'bulv','bul56',2),(59,5,'Васечко Андрей Карпович','старший преподаватель',NULL,NULL,NULL,NULL,'vasa','vas57',2),(60,5,'Вувуникян Юрий Микиртычевич','профессор','доктор физико-математических наук',NULL,NULL,NULL,'vuvun','vuv58',2),(61,5,'Гончарова Марина Николаевна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'gonm','gon59',2),(62,5,'Кулеш Елена Евгеньевна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'kule','kul60',2),(63,5,'Кузьмич Андрей Викторович','старший преподаватель',NULL,NULL,NULL,NULL,'kuza','kuz61',2),(64,5,'Мисюк Виктор Романович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'misv','mis62',2),(65,5,'Можджер Гражина Тадеушевна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'mozgd','mozg63',2),(66,5,'Наумович Елена Анатольевна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'naume','naum64',2),(67,5,'Пчельник Владимир Константинович','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'pchel','pchel65',2),(68,5,'Ровба Евгений Алексеевич','профессор','доктор физико-математических наук','заведующий кафедрой',NULL,NULL,'rove','rov66',2),(69,5,'Сетько Елена Александровна','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'sete','set67',2),(70,5,'Смотрицкий Константин Анатольевич','доцент','кандидат физико-математических наук',NULL,NULL,NULL,'smotk','smot68',2),(71,5,'Шевченя Дмитрий Николаевич','старший преподаватель',NULL,NULL,NULL,NULL,'shevd','shev69',2),(72,5,'Шпак Дарья Сергеевна','доцент','кандидат физико-математических наук','net','null','null','shpak','shpak70',2),(73,1,'superadmin','super','super','super','super','super','superadmin','zxcdsaqwe',1);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
