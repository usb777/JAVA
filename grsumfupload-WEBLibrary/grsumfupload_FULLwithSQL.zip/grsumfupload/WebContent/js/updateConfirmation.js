﻿         /* this function ask about update publication info, from admin*/    
        function getUpdateConfirmationUserPublication(file_id,path1)
        {
               var retVal = confirm("Вы хотите изменить данные этой публикации ? bs_id="+file_id);
               if( retVal == true ){
                  //document.write ("User wants to continue!");
            	   window.location=path1+"/backendUpdatePublication.jsp?bs_id="+file_id+"&action=update"
                  return true;
               }
               else{
                  // document.write ("User does not want to continue!");
                  return false;
               }
            }   // end of function




/* this function ask about update publication info, from admin*/    
        function getUpdateConfirmation(file_id,path1){
               var retVal = confirm("Вы хотите изменить данные этой публикации ? bs_id="+file_id);
               if( retVal == true ){
                  //document.write ("User wants to continue!");
            	   window.location=path1+"/backendSAUpdatePublication.jsp?bs_id="+file_id+"&action=update"
                  return true;
               }
               else{
                  // document.write ("User does not want to continue!");
                  return false;
               }
            }   // end of function
       
       
       
    /* this function ask about update User info, from admin*/
            function getUpdateSAUsersConfirmation(user_id,path1)
            {
                var retVal = confirm("Вы хотите изменить данные этого пользователя ? user_id="+user_id);
                if( retVal == true ){
                   //document.write ("User wants to continue!");
             	   window.location=path1+"/backendSAUpdateUser.jsp?s_id="+user_id+"&action=updateUser"
                   return true;
                }
                else{
                   // document.write ("User does not want to continue!");
                   return false;
                }
             } // end of function
            
            
            
            /* this function ask about update Kafedra info, from admin*/
            function getUpdateSAKafedraConfirmation(kafedra_id,path1)
            {
                var retVal = confirm("Вы хотите изменить данные этой кафедры ? kafedra_id="+kafedra_id);
                if( retVal == true ){
                   //document.write ("User wants to continue!");
             	   window.location=path1+"/backendSAUpdateKafedra.jsp?k_id="+kafedra_id+"&action=updatekafedra"
                   return true;
                }
                else{
                   // document.write ("User does not want to continue!");
                   return false;
                }
             } // end of function
            