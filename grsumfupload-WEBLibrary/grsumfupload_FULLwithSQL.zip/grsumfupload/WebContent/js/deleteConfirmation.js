﻿           // delete file from SuperAdmin 
           function getDeleteConfirmation(file_id,path1){
               var retVal = confirm("Вы хотите удалить этот файл ? ids="+file_id);
               if( retVal == true ){
                  //document.write ("User wants to continue!");
            	   window.location=path1+"/SuperadminBackEndController?bs_id="+file_id+"&action=delete"
                  return true;
               }
               else{
                  // document.write ("User does not want to continue!");
                  return false;
               }
            }
       
    
            // delete file from User
            function getDeleteConfirmationByUser(file_id,path1){
                var retVal = confirm("Вы хотите удалить этот файл ? ids="+file_id);
                if( retVal == true ){
                   //document.write ("User wants to continue!");
             	   window.location=path1+"/ControllerBackEndMain?bs_id="+file_id+"&action=delete"
                   return true;
                }
                else{
                   // document.write ("User does not want to continue!");
                   return false;
                }
             }
            
            
            
            /* this function ask about delete User info, from admin*/
            function getdeleteSAUsersConfirmation(user_id,path1)
            {
                var retVal = confirm("Вы хотите удалить данные этого пользователя ? user_id="+user_id);
                if( retVal == true ){
                   //document.write ("User wants to continue!");
             	   window.location=path1+"/SABackEndControllerSotrudnikiChange?s_id="+user_id+"&action=delete"
                   return true;
                }
                else{
                   // document.write ("User does not want to continue!");
                   return false;
                }
             } // end of function
        