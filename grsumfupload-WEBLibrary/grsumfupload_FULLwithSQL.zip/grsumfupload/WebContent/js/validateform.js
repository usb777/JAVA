function validate(form) 
{ if (form.username.value=="") { alert("Please fill in Username"); form.username.focus(); }
   else if (form.password.value=="") { alert("Please fill in Password");form.password.focus(); }
   else { form.submit(); } 
}