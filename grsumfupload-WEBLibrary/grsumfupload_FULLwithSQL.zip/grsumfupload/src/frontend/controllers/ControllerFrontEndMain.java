package frontend.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import backend.models.ModelBackEndMain;
import frontend.models.ModelFrontEndMain;
import mvc.util.UsefulMethods;



/*  How to send data from servlet to JSP
 * 
  String a=req.getParameter("username");
   req.setAttribute("name", a);
   RequestDispatcher rd=req.getRequestDispatcher("/login.jsp");
   rd.forward(req, resp);

//in jsp follow these steps shown below in the program

  <% 
    String name=(String)request.getAttribute("name");
      out.print("your name"+name);
  %>
 
 * */




/**
 * Servlet implementation class MainController
 */
@WebServlet("/ControllerFrontEndMain")
public class ControllerFrontEndMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerFrontEndMain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8"); // eto na vsiakij sluchai))
		
	    HttpSession session = request.getSession(true);
		
		PrintWriter pw = response.getWriter(); 	
			
		ModelFrontEndMain mfemain = new ModelFrontEndMain();
	
		
		/*
		
		
		String fio="";
		fio=mfemain.getFio1();   // This is true MVC call from model !!!
		
	     int[] cars =new int[] {4,5,6,7,8}; 
	   
		 request.setAttribute("zztop", "Another variable");
		 request.setAttribute("cars", cars);
		 request.setAttribute("all_fio", fio); 
		 */
		 
		 RequestDispatcher view = request.getRequestDispatcher("index.jsp");
		 view.forward(request, response);
		
		
		
		 
	} // doGet

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		
		
	}
	
	public String getAllDocs() throws ServletException, IOException
	{	return "</br>String from Controller</br>"; 	}
	
	
	// MAssiv Imion failov
	public String[] getFilenamesFromModel ()  
	{ 
		 String[] filenames;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	    filenames = mfem.getFILENamesPublications();		
	    return filenames;		
	}
	
	// MAssiv Imion publikacij
	public String[] getNamesFromModel ()  
	{ 
		 String[] names;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   names = mfem.getNamesPublications();	
	    return names;		
	}
	
	// MAssiv Imion publikacij
	public String[] getDescriptionFromModel ()  
	{ 
		 String[] description;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   description = mfem.getDescription();	
	    return description;		
	}
	
	public String[] getYearFromModel ()  
	{ 
		 String[] year;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   year = mfem.getYear();	
	    return year;		
	}
	
	public String[] getUsernamesOfPublicationFromModel ()  
	{ 
		 String[] usernames;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   usernames = mfem.getUsernameOfPublication();	
	    return usernames;		
	}

/*--------------------------------------------------Get Data aboutus.jsp-----------------------------------------------------------------*/	
	public String[] getKafedraNameFromModel ()  
	{ 
		 String[] kafedra_names;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   kafedra_names = mfem.getKafedraName();	
	    return kafedra_names;		
	}
	
	public String[] getKafedraCabinetFromModel ()  
	{ 
		 String[] kafedra_cabinets;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   kafedra_cabinets = mfem.getKafedraCabinet();	
	    return kafedra_cabinets;		
	}
	
	public String[] getKafedraEmailFromModel ()  
	{ 
		 String[] kafedra_emails;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   kafedra_emails = mfem.getKafedraEmail();	
	    return kafedra_emails;		
	}
	public String[] getKafedraTelefon1FromModel ()  
	{ 
		 String[] kafedra_telefons1;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	     kafedra_telefons1 = mfem.getKafedraTelefon1();
	    return kafedra_telefons1;		
	}
	
	
	/*
	 * Controller function return all users by kafedra
	 * 
	 * */
	public String[] getAllUsersByKafedraFromModel(String k_id)  
	{ 
		 String[] allusersbykafedra;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	     allusersbykafedra = mfem.getAllUsersDataByKafedra(k_id);
	    return allusersbykafedra;		
	}	
	
	public String getKafedraNameByKafedraID(String k_id)
	{ 
		 String kafedra_name="";
		 ModelFrontEndMain mfem = new ModelFrontEndMain();		
		 kafedra_name = mfem.getKafedraNameByKafedraID(k_id);
	    return kafedra_name;	
		
	}
	
/*Get all user ID who have publication, DElaet massiv tolko iz unikalnyx znachenij*/
	public String[] getUserIdAllPublicationUnique ()  
	{ 
		 String[] IdsWithPublication;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	   IdsWithPublication = mfem.getAllUserIDWithPublications();
	   UsefulMethods um = new UsefulMethods();
	   
	   String[] uniqueIds = um.removedublicates(IdsWithPublication);
	   
	    return uniqueIds;		
	}
	
	public String getFIOById(String userid)
	{
		String username="";
		 ModelFrontEndMain mfem = new ModelFrontEndMain();
		 username=mfem.getFIOById(userid);
		 
		return username;
	}
	
	public String getLoginById(String userid)
	{
		String login="";
		 ModelFrontEndMain mfem = new ModelFrontEndMain();
		 login=mfem.geLoginById(userid);
		 
		return login;
	}
	
public String[]	getAllPublicationsByUserIDfromModel(String s_id)
{  ModelFrontEndMain mfem = new ModelFrontEndMain();
	String[] allpublicationByUserid;
		
	allpublicationByUserid = mfem.getAllPublicationsByUserID(s_id);
  return allpublicationByUserid;
}	

	
	
	
	

}
