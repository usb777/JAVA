package frontend.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import frontend.models.ModelFrontEndMain;
// obiazatelno perepisat

/**
 * Servlet implementation class ControllerLogin
 */
@WebServlet("/ControllerFrontEndLogin")
public class ControllerFrontEndLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerFrontEndLogin() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException  
	{
		// Obrabotka i proverka polei logirovaniya. 
		/*  Esli polzovatel s zadannym parolem est v baze  - to perekidyvaem v adminku, 
		 *  esli net perekidyvaem na ---404.jsp---  stranicu, s opisaniem oshibki)
		 *  TODO:   ----Right now i make without Logik MVC, later I remake----
		 * */
		
		response.setContentType("text/html");
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		PrintWriter pw = response.getWriter();
		
		HttpSession session = request.getSession(true);  // start session! 
		
		 String  mistake="";
		 boolean inputMissing = false;								    // flag for test of missing input
		 boolean passwordMismatch = false;							    // flag for test of mismatched passwords
		 String[] inputNames = new String[] {"username", "password"	};  // create array of html input names
		 
		 
		 // start proverki na pustye polia
			for (int i = 0; i < inputNames.length; i++)
			{										// for each html input
				String inputValue = request.getParameter(inputNames[i]);			// get input value for input name
				
				if (  (inputValue == null) || (inputValue.equals(""))   )
				{						// if null / empty
					inputMissing = true;																	// set flag true
				} //if
			}  //for
			// end  proverki na pustye polia	 
		 
		
			
			if (inputMissing)  // esli oshibka, odno iz polei pustoe
			   {																				// if flag true, 

				 mistake = "<center><H2><font color='red'>Input missing, try again, please</font></H2></center>";
				 
				 request.setAttribute("mistake", mistake); 
		  		 RequestDispatcher error404 = request.getRequestDispatcher("404.jsp");
		    	 error404.forward(request, response);
		    
		    /*	 
		    	  session.setAttribute("mistake", mistake);  
		    	  response.sendRedirect("404.jsp"); 
		    */	 
		    	 
				// handle error
			   } //if inputmissing  = true , propusheno i ne zapolneno odno iz polei		
			else 
			{  // TODO: Boolean function from MVC!  from controller "username" and "pass"  --> to ModelMain, and return boolean function
			/*	
				Connection conn = null;
			    try
			    {
			       
				  Class.forName("com.mysql.jdbc.Driver");
			       conn = DriverManager.getConnection(
			    		   "jdbc:mysql://localhost:3306/db_grsumf" , "root", "");
			                Statement stmt = conn.createStatement();

			         
		 ResultSet rs = stmt.executeQuery("SELECT s_login, s_password FROM sotrudniki  where s_login='" + request.getParameter("username") + "' and s_password='" + request.getParameter("password") + "'");
			   
			       if (rs.next() )  		       
			       {
			    	   session.setAttribute("username", request.getParameter("username"));
					   response.sendRedirect("backend.jsp");
			       }
			       
			       
			       
			       else 
			       {
			       	   mistake = "<center> <H2><font color='red'>User ID and Password does not match!</font></H2></center>"; 		  
			    	   
			     	  request.setAttribute("mistake", mistake); 
			          RequestDispatcher error404 = request.getRequestDispatcher("404.jsp");
				      error404.forward(request, response);
				      
			        }
			       
			       
			    } // try
			    catch (Exception e){
					pw.println("Registration Error:"+e);
					System.out.println("Error take values from  database");
					e.printStackTrace();
				}
				
				
				*/
				ModelFrontEndMain mfem = new ModelFrontEndMain();
				
				if ( mfem.existUser(request.getParameter("username"), request.getParameter("password")) )
				{ 
					if (request.getParameter("username").equals("superadmin"))
					 {
						 session.setAttribute("username", request.getParameter("username"));
						   session.setAttribute("fio",mfem.getFioByLogin(request.getParameter("username")));					   
						   response.sendRedirect("backendSuperAdmin.jsp");
					 }
					else 
					{
					   session.setAttribute("username", request.getParameter("username"));
					   session.setAttribute("fio",mfem.getFioByLogin(request.getParameter("username")));					   
					   response.sendRedirect("backend.jsp");
					}
				}
				else 
				{
					 mistake = "<center> <H2><font color='red'>User ID and Password does not match!</font></H2></center>"; 
			     	  request.setAttribute("mistake", mistake); 
			          RequestDispatcher error404 = request.getRequestDispatcher("404.jsp");
				      error404.forward(request, response);
				}
				
				
			} //else		
			
			
			
			
		 
		 
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
	}

}
