/*
 * This Servlet Controller will make
 * search by files, by names of files, by description (��������)
 * 
 * 
 * */

package frontend.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import frontend.models.ModelFrontEndMain;

/**
 * Servlet implementation class ControllerFrontEndSearch
 */
@WebServlet("/ControllerFrontEndSearch")
public class ControllerFrontEndSearch extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerFrontEndSearch() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		String[] search_results;
		search_results =this.getSearchingResultsFromModel(request.getParameter("q"));
		request.setAttribute("search_results", search_results);
		 request.getRequestDispatcher("search.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
		String[] search_results;
		search_results =this.getSearchingResultsFromModel(request.getParameter("q"));
		request.setAttribute("search_results", search_results);
		 request.getRequestDispatcher("search.jsp").forward(request, response);
	}
	
	public String[] getSearchingResultsFromModel (String parsearch)  
	{ 
		 String[] search_results;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	     search_results = mfem.simpleSearch(parsearch);
	    return search_results;		
	}
	
	public String getPublicationInfoByIdFromModel (String bs_id)  
	{ 
		 String sr_infos;		
	     ModelFrontEndMain mfem = new ModelFrontEndMain();		
	     sr_infos = mfem.getAllPublicationsByFileID(bs_id);
	    return sr_infos;		
	}
	
	

}
