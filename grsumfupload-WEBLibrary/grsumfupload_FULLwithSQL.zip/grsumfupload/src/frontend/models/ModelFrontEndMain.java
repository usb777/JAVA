package frontend.models;

import java.sql.*;

import mvc.util.DBConnection;

public class ModelFrontEndMain 
{
	
	private String username;
	private String password;
	
	 private static final String SUPER_SQL = "SELECT * FROM brain_storage "; // !right now doesnt use in code
	 private static final String ORDER_BY = " order by s_id";

	 
// Get data for kafedra
	 private static final String SUPER_SQL_kafedra = "SELECT * FROM kafedra "; // !right now doesnt use in code
	 private static final String ORDER_BY_kafedra = " order by k_id";
	 
 
 // Section for Login logik
 private String getUsername() {
		return username;
	}

 private void setUsername(String username) {
		this.username = username;
	}

 private String getPassword() {
		return password;
	}

 private void setPassword(String password) {
		this.password = password;
	}
 
 public boolean existUser(String username, String password)
 {
	 this.setUsername(username);
	 this.setPassword(password);;
	 
	 
	 
	 boolean existuser_flag=false;
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  
		  
	 try
	  {
	     con = DBConnection.createConnection(); //establishing connection
	     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	    // resultSet = statement.executeQuery("SELECT s_fio FROM sotrudniki order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	     resultSet = statement.executeQuery("SELECT s_login, s_password FROM sotrudniki  where s_login='" +this.getUsername() + "' and s_password='" + this.getPassword() + "'");
	
	     if (resultSet.next())
	       { existuser_flag = true;}
	     
	     else {  existuser_flag = false; }
	     
	 statement.close();
	 
	  } //try
	 	 
	  catch(SQLException e)
	  {
	     e.printStackTrace();
	     System.out.println("Error is --- "+e);
	  }	 
	 
	
	 return existuser_flag;
 }

 public String getFioByLogin(String username)
 { 
	  String fio="";
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  
		  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT s_fio FROM sotrudniki where s_login='"+username+"' order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		if (resultSet.next() )
		 { 
			fio = resultSet.getString("s_fio");    // Error
		 }    
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
	 return fio;
 }
 
  
 
 
 
 
 public String[] getFILENamesPublications()
 {
	 // String sql = "SELECT bs_filename FROM brain_storage order by bs_name";
	  String sql = SUPER_SQL+ORDER_BY;
	  
	  String[] names;
	  names = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  names = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 names[i] = resultSet.getString("bs_filename");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return names;	
  }	  
 
 

 public String[] getNamesPublications()
 {
	//  String sql = "SELECT bs_name FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL+ORDER_BY;
	  
	  String[] names;
	  names = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  names = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 names[i] = resultSet.getString("bs_name");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return names;	
  }	 
 
 
 
 public String[] getDescription()
 {
	//  String sql = "SELECT bs_description FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL+ORDER_BY;
	  
	  String[] description;
	  description = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  description = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 description[i] = resultSet.getString("bs_description");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return description;	
  }	 
 
 
 public String[] getYear()
 {
	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL+ORDER_BY;
	  
	  String[] year;
	  year = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  year = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 year[i] = resultSet.getString("bs_year");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return year;	
  }	  
 
 
 public String[] getUsernameOfPublication()
 {
	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";

	 String sql = "SELECT a.bs_filename, a.bs_name , b.s_login "+
	              "FROM  brain_storage a "+ 
	              " INNER JOIN sotrudniki b" +
	              " ON a.s_id = b.s_id" +
	              " ORDER BY a.s_id";
	  
	  String[] usernames;
	  usernames = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  usernames = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 usernames[i] = resultSet.getString("b.s_login");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return usernames;	
  }	 
 
 
 /*  Nije budet informaciya o vsex kafedrax dlia stranicy contact.jsp   */
 
 public String[] getKafedraName()
 {
	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL_kafedra+ORDER_BY_kafedra;
	  
	  String[] kafedra;
	  kafedra = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  kafedra = new String[rowcount]; // rashiriaem na  pravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 kafedra[i] = resultSet.getString("k_name");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return kafedra;	
  }
 
 
 public String[] getKafedraCabinet()
 {
	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL_kafedra+ORDER_BY_kafedra;
	  
	  String[] kafedra_cabinet;
	  kafedra_cabinet = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  kafedra_cabinet = new String[rowcount]; // rashiriaem na  pravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 kafedra_cabinet[i] = resultSet.getString("k_cabinet");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return kafedra_cabinet;	
  }	
 
 
 
 public String[] getKafedraEmail()
 {
	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL_kafedra+ORDER_BY_kafedra;
	  
	  String[] kafedra_email;
	  kafedra_email = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  kafedra_email = new String[rowcount]; // rashiriaem na  pravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 kafedra_email[i] = resultSet.getString("k_email");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return kafedra_email;	
  }	
 
 
 
 public String[] getKafedraTelefon1()
 {
	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";
	 String sql = SUPER_SQL_kafedra+ORDER_BY_kafedra;
	  
	  String[] kafedra_telefon;
	  kafedra_telefon = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  kafedra_telefon = new String[rowcount]; // rashiriaem na  pravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 kafedra_telefon[i] = resultSet.getString("k_telefon1");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return kafedra_telefon;	
  }	
 
 /*
  * method get Info about all users and put in String Array - razdelitel #
  * 
  * 
  * */
 public String[] getAllUsersDataByKafedra(String k_id)
 {
	  
	  String sql = "SELECT * FROM sotrudniki WHERE k_id='"+k_id+"' and s_login<>'superadmin'   order by s_id";
	  String[] allusers;
	  allusers = new String[2];
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  allusers = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  { 
		 
		
		 String s_id = resultSet.getString("s_id");            
		  k_id = resultSet.getString("k_id");                
		 String s_fio= resultSet.getString("s_fio");              
		 String s_rank = resultSet.getString("s_rank");           
		 String s_degree = resultSet.getString("s_degree");           
		 String s_position = resultSet.getString("s_position");         
		 String s_email = resultSet.getString("s_email");          
		 String s_telefon= resultSet.getString("s_telefon");           
		 String s_login = resultSet.getString("s_login");          
		 String s_password = resultSet.getString("s_password");            
		 String s_role = resultSet.getString("s_role");     
		 
		 if (s_id!=null)  { }  else {s_id="";}
		 if (k_id!=null)  { }  else {k_id="";}
		 if (s_fio!=null)  { }  else   {s_fio="";}
		 if (s_rank!=null)  { }  else   {s_rank="";}
		 if (s_degree!=null)  { }  else   {s_degree="";}
		 if (s_position!=null) { }  else   {s_position="";}
	     if (s_email!=null)  { }  else   {s_email="";}
	     if (s_telefon!=null){ }  else   {s_telefon="";}
	     if (s_login!=null)  { }  else   {s_login="";}
	     if (s_password!=null) { }  else   {s_password="";}
	     if (s_role!=null)  { }  else   {s_role="";}
		  
		 allusers[i] =s_id+"#"+k_id+"#"+s_fio+"#"+s_rank+"#"+s_degree+"#"+s_position+"#"+s_email+"#"+s_telefon+
		 "#"+s_login+"#"+s_password+"#"+s_role;
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return allusers;	
  }  // end of method
 
 public String getKafedraNameByKafedraID(String k_id)
 { 
	  String k_name="";
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  
		  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT k_name FROM kafedra where k_id='"+k_id+"' "); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		if (resultSet.next() )
		 { 
			k_name = resultSet.getString("k_name");    // Error
		 }    
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
	 return k_name;
 }
 
 /*************************All data for alldocs.jsp PUBLICATION BY USER*********************************************/
 public String[] getAllPublicationsByUserID(String s_id)
 {
	  
	  String sql = "SELECT * FROM brain_storage where s_id='"+s_id+"'   order by s_id";
	  String[] allpublicationByuser;
	  allpublicationByuser = new String[2];
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  allpublicationByuser = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  { 
		 
		
		 String bs_id = resultSet.getString("bs_id");                
		 String bs_name= resultSet.getString("bs_name");              
		 String bs_description = resultSet.getString("bs_description");           
		 String bs_year = resultSet.getString("bs_year");           
		 String bs_filename = resultSet.getString("bs_filename");         
		         
		
		  
		 allpublicationByuser[i] =bs_id+"#"+bs_name+"#"+bs_description+"#"+bs_year+"#"+bs_filename;
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return allpublicationByuser;	
  }  // end of method	
 
 
 /*
  Beriom massiv id vsex polzovatelei u kotoryx est publikacii, poka s dublikatami
  * */
 public String[] getAllUserIDWithPublications()
 {
	  
	  String sql = "SELECT s_id FROM brain_storage order by s_id";
	  
	 
		
	  String[] ids;
	  ids = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
      {  rowcount= resultSet.getRow(); } 
	  
	  else 
      {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
      }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  ids = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 ids[i] = resultSet.getString("s_id");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
    return ids;		
  }  // end of method	
 
 
 public String getFIOById(String userid)
	{
		String userName=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT s_fio FROM sotrudniki  where s_id='" +userid + "'");
		
		     if (resultSet.next())
		       { 
		    	 userName = resultSet.getString("s_fio");
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return userName;
	}
 
 public String geLoginById(String userid)
	{
		String login=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT s_login FROM sotrudniki  where s_id='" +userid + "'");
		
		     if (resultSet.next())
		       { 
		    	 login = resultSet.getString("s_login");
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return login;
	}
 
 /* 
  * Simple search ************************************************************************************ 
  * */
 
 public String[] simpleSearch(String parsearch)
 {
	  
	  String sql = "SELECT bs_id,bs_name, bs_filename, bs_description,bs_year FROM brain_storage "+
	  "WHERE (bs_name LIKE '%"+parsearch+"%' OR bs_filename LIKE '%"+parsearch+"%' OR bs_description LIKE '%"+parsearch+"%' OR bs_year LIKE '%"+parsearch+"%' ) order by bs_name ";
	  
	 
		
	  String[] ids;
	  ids = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
      {  rowcount= resultSet.getRow(); } 
	  
	  else 
      {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
      }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  ids = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 ids[i] = resultSet.getString("bs_id");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
    return ids;		
  }  // end of method
 
 public String getAllPublicationsByFileID(String bs_id)
 {
	  
	  String sql = "SELECT * FROM brain_storage where bs_id='"+bs_id+"'   order by bs_id";
	  String publication="";
	 
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	 
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	 
	  String login="";
	 if(resultSet.next()) // Until next row is present otherwise it return false
	  { 
		
		 bs_id = resultSet.getString("bs_id");                
		 String bs_name= resultSet.getString("bs_name");              
		 String bs_description = resultSet.getString("bs_description");           
		 String bs_year = resultSet.getString("bs_year");           
		 String bs_filename = resultSet.getString("bs_filename"); 
		 
		 String s_id = resultSet.getString("s_id");
		 
		 resultSet = statement.executeQuery("SELECT s_login FROM sotrudniki  where s_id='" +s_id + "'");
			
	     if (resultSet.next())
	       { 
	    	 login = resultSet.getString("s_login");
	       }
		
		         
		
		  
		 publication =bs_id+"#"+bs_name+"#"+bs_description+"#"+bs_year+"#"+bs_filename+"#"+login;
		 System.out.println(publication);
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return publication;	
  }  // end of method	
 
 

} //class Model
