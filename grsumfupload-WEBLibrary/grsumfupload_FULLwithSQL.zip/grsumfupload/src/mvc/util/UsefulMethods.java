package mvc.util;

import java.util.ArrayList;
import java.util.List;

public class UsefulMethods
{

	
	public String[] removedublicates(String[] arr)
	{ String new_arr[];

	   List<String> arrList = new ArrayList<String>();
	   int cnt= 0;
	  //List<String> arrList = Arrays.asList(arr);
	    List<String> lenList = new ArrayList<String>();
	      for(int i=0;i<arr.length;i++){
	        for(int j=i+1;j<arr.length;j++)
	        {
	          if(arr[i].equals(arr[j]))
	           {         cnt+=1;      }                
	        } //for j
	   if(cnt<1){   arrList.add(arr[i]);   }
	     cnt=0;
	   }

	new_arr = new String[arrList.size()];

	  for(int k=0;k<arrList.size();k++)
	   { new_arr[k]=  arrList.get(k);  }
	  
		return new_arr;
	}
}
