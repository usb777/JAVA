package backend.models;

import java.sql.*;

import mvc.util.DBConnection;


public class ModelUploader
{
	
	public String getUserId(String username)
	{
		String userID=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		    // resultSet = statement.executeQuery("SELECT s_fio FROM sotrudniki order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		     resultSet = statement.executeQuery("SELECT s_id, s_login FROM sotrudniki  where s_login='" +username + "'");
		
		     if (resultSet.next())
		       { 
		    	 userID = resultSet.getString("s_id");
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return userID;
	}
	
	
	// INSERT INTO brain_storage (s_id,bs_url,bs_name,bs_description,bs_year) 	 VALUES ("5","www.rambler.ru","best_file.doc","asdhajkdhahsdjkl asdasdkldkl;as asdasd","1996");
	
	public void insertDocsByUser(String userid, String bs_url, String bs_name, String bs_description, String bs_year, String bs_filename)
	{
		
		 Connection con = null;
		 Statement statement = null;
		 ResultSet resultSet = null;
		  String sql = "INSERT INTO brain_storage (s_id, bs_url, bs_name, bs_description, bs_year, bs_filename) 	"
				  + "VALUES ('"+userid+"','"+bs_url+"','"+bs_name+"','"+bs_description+"','"+bs_year+"' ,'"+bs_filename+"'    ) ";
			  
			 try
			  {
			     con = DBConnection.createConnection(); //establishing connection
			     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		         
			     statement.executeUpdate(sql);
		 	
			 statement.close();
			 
			  } //try
			 	 
			  catch(SQLException e)
			  {
			     e.printStackTrace();
			     System.out.println("Error is --- "+e);
			  }	 
		
		System.out.println("!!!!!!sQL!!!!!!  ==="+sql);
		
		
		
	}
	
	

}
