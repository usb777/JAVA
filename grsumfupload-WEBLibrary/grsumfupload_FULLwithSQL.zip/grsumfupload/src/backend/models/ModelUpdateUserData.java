package backend.models;

import java.sql.*;

import mvc.util.DBConnection;


public class ModelUpdateUserData 
{

	 public String getFioByLogin(String username)
	 { 
		  String fio="";
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
			 try
			  {
			     con = DBConnection.createConnection(); //establishing connection
			     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
			     resultSet = statement.executeQuery("SELECT s_fio FROM sotrudniki where s_login='"+username+"' order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			if (resultSet.next() )
			 { 
				fio = resultSet.getString("s_fio");    // Error
			 }    
			 statement.close();
			 
			  } //try
			 	 
			  catch(SQLException e)
			  {
			     e.printStackTrace();
			     System.out.println("Error is --- "+e);
			  }	 
			 
		 return fio;
	 }
	 
	 
	 
	 public static String[] returnAllUserDataStringArray(String username)
	 {
	 String[] alluserdata;
	 alluserdata = new String[10]; // Create an array of 3 elements
      
	 Byte kafedra_id=0;
		
	 
	 Connection con = null;
	 Statement statement = null;
	 ResultSet resultSet = null;
	  
		  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT k_id, s_fio, s_rank, s_degree, s_position, s_email, s_telefon, s_login, s_password FROM sotrudniki where s_login='"+username+"' order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		if (resultSet.next() )
		 { 
			//fio = resultSet.getString("s_fio");    // Error
			kafedra_id = resultSet.getByte("k_id");
			alluserdata[0] = resultSet.getString("k_id");
			alluserdata[1] = resultSet.getString("s_fio");
			alluserdata[2] = resultSet.getString("s_rank");
			alluserdata[3] = resultSet.getString("s_degree");
			alluserdata[4] = resultSet.getString("s_position");
			alluserdata[5] = resultSet.getString("s_email");
			alluserdata[6] = resultSet.getString("s_telefon");
			alluserdata[7] = resultSet.getString("s_login");
			alluserdata[8] = resultSet.getString("s_password");
		 }
	     
		resultSet = statement.executeQuery("SELECT k_id, k_name FROM kafedra where k_id='"+kafedra_id+"' order by k_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		if (resultSet.next() )
		 { 
			alluserdata[9]= resultSet.getString("k_name");
		 }
		
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
	 
	 
	 
	 

	 return( alluserdata ); // Return the **reference** (location) of the array
	 }
	 
	public void updateUserData (String username, String k_id, String s_fio, String s_rank,String s_degree,String s_position, String s_email, String s_telefon,String s_password)
	{
		
		 Connection con = null;
		 Statement statement = null;
		 ResultSet resultSet = null;
		  
			  
			 try
			  {
			     con = DBConnection.createConnection(); //establishing connection
			     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
			//     resultSet = statement.executeQuery("SELECT k_id, s_fio, s_rank, s_degree, s_position, s_email, s_telefon, s_login, s_password FROM sotrudniki where s_login='"+username+"' order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	statement.executeUpdate("update sotrudniki set k_id = '"+k_id+"' , s_fio='"+s_fio+"' , s_rank='"+s_rank+"' , s_degree='"+s_degree+"'"
			+ ", s_position='"+s_position+"' , s_email='"+s_email+"' , s_telefon='"+s_telefon+"' , s_password='"+s_password+"'   	where s_login='"+username+"'");		
			 statement.close();
			 
			  } //try
			 	 
			  catch(SQLException e)
			  {
			     e.printStackTrace();
			     System.out.println("Error is --- "+e);
			  }	 
		
	} //end UpdateUserData
	 
  public String getKafedraIdByKafedraName(String kafedra_name)
  { 
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  String k_id = "";
		  
	 try
	  {
	     con = DBConnection.createConnection(); //establishing connection
	     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	    // resultSet = statement.executeQuery("SELECT s_fio FROM sotrudniki order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	     resultSet = statement.executeQuery("SELECT k_id FROM kafedra WHERE k_name='"+kafedra_name+"'   ");
	
	     if (resultSet.next())
	       { 
	    	 k_id = resultSet.getString("k_id");
	       }
	     
	 statement.close();
	 
	  } //try
	 	 
	  catch(SQLException e)
	  {
	     e.printStackTrace();
	     System.out.println("Error is --- "+e);
	  }	 
	  
	  
	  
	return k_id;
  }
	
	 	
}
