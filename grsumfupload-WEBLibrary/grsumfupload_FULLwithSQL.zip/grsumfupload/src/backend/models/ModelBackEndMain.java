package backend.models;
import java.sql.*;

import mvc.util.DBConnection;

public class ModelBackEndMain
{

	private int userid;
	
	 private int getUserid() 
	 {
			return userid;
	 }

	 private void setUserid(int userid) 
	 {
			this.userid = userid;
	 }
	
	/*
	public String[] getAllDocsFilenameByUser(String user_id)
	{
		this.setUserid(userid);
		
		String[] filenames;
		filenames = new String[100000]; // TODO : sdelat funkciu , kotoraya budet vozvrashat kol-vo dokumentov po kajdomu uzeru
		
		 Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			String bs_filename ="";
			
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  
		  resultSet = statement.executeQuery("SELECT * FROM brain_storage where s_id ='"+user_id+"' order by s_id"); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 filenames[i] = resultSet.getString("bs_filename");	    
		  i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }	 
		
		return filenames;
	}
	
	*/
	
	// Sobiraet vse imena failov v String massiv
	
	  /*
	     Funkciya sobiraet v massiv imena failov- rabot dannogo polzovatelia  
	  
	  */
	  public String[] getfilenames(int userid)
	  {
		  String sql = "SELECT * FROM brain_storage where s_id =? order by s_id";
			
		  String[] filenames;
		  filenames = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  PreparedStatement pstmt =null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		 
		  pstmt = con.prepareStatement(sql);
		  pstmt.setInt(1,  userid);
		  resultSet= pstmt.executeQuery();
		  
		 // resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		 // pstmt = con.prepareStatement(sql);
		//  pstmt.setInt(1,  userid);
		  resultSet= pstmt.executeQuery();
		//  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  filenames = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 filenames[i] = resultSet.getString("bs_filename");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return filenames;	
	   }
	  
	  /*
	   *  Funkciya sobiraet v massiv nazvaniya vsex rabot dannogo polzovatelia  
	  
	  */
	  public String[] getNames(int userid)
	  {
		  //String sql = "SELECT bs_name FROM brain_storage where s_id ='"+userid+"' order by s_id";
		  String sql = "SELECT bs_name FROM brain_storage where s_id =? order by s_id";
			
		  String[] names;
		  names = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  PreparedStatement pstmt =null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		 
		  pstmt = con.prepareStatement(sql);
		  pstmt.setInt(1,  userid);
		  resultSet= pstmt.executeQuery();
		//  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  resultSet= pstmt.executeQuery();
		//  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  names = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 names[i] = resultSet.getString("bs_name");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return names;	
	   }
	  
	  
	  /*
	   *  Funkciya sobiraet v massiv description(OPISANIE) vsex rabot dannogo polzovatelia  
	  
	  */
	  public String[] getDescription(int userid)
	  {
		  String sql = "SELECT bs_description FROM brain_storage where s_id =? order by s_id";
		  
		  String[] description;
		  description = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  PreparedStatement pstmt =null;	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		 
		  pstmt = con.prepareStatement(sql);
		  pstmt.setInt(1,  userid);
		  resultSet= pstmt.executeQuery();
		  
		 // resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  resultSet= pstmt.executeQuery();
		  //resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  description = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 description[i] = resultSet.getString("bs_description");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return description;	
	   }

	  
	  /*
	   *  Funkciya sobiraet v massiv years( Gody) vsex rabot dannogo polzovatelia  
	  
	  */
	  public String[] getYear(int userid)
	  {
		  String sql = "SELECT bs_year FROM brain_storage where s_id =? order by s_id";
		  
		  String[] year;
		  year = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  PreparedStatement pstmt =null;
		  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		 
		 
		  pstmt = con.prepareStatement(sql);
		  pstmt.setInt(1,  userid);
		  resultSet= pstmt.executeQuery();
		  
		//  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  resultSet= pstmt.executeQuery();
		 // resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  year = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 year[i] = resultSet.getString("bs_year");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return year;	
	   }	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  
	  /*
	     Vspomogatelnaya funkciya  , vozvrashaet id usera po imeni,  
	      ispolzuetsia v Controllere dlia sobiraniya polnoi funkcii dannyx  
	  */
	  public int getUserId(String username)
	 	{
	 		int userID=0; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT s_id FROM sotrudniki  where s_login='" +username + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 userID = resultSet.getInt("s_id");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return userID;
	 	}

	  /*	
		
		This function delete file from Database by id
	*/ 
	  public void deletePublicationById(String id)
	  {
	     //DELETE FROM brain_storage WHERE bs_id='27'	
	  	String sql = "DELETE FROM brain_storage WHERE bs_id=?  ";
	  
	  	  Connection con = null;
	  	  Statement statement = null;
	  	  ResultSet resultSet = null;
	  	  PreparedStatement pstmt =null; 
	  	 try
	  	  {
	  	  con = DBConnection.createConnection(); //establishing connection
	  	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  	 
	  	   pstmt = con.prepareStatement(sql);
	  	   pstmt.setString(1, id);
	  	   pstmt.executeUpdate();
	  	  
	  	
	  	 statement.close();
	  	  }
	  	  catch(SQLException e)
	  	  {
	  	  e.printStackTrace();
	  	  }
	  }
	  
	  
	 
	  /*	
		
		This function update file publication from Database by id
	*/ 
	  
	  public void UpdatePublicationById(String bs_id, String bs_name,  String bs_description, String bs_year)
	  {
	   //DELETE FROM brain_storage WHERE bs_id='27'	
	  	String sql = "UPDATE brain_storage SET bs_name=? , bs_description=?, bs_year=?	WHERE bs_id =? ";
	  	
	  	  Connection con = null;
	  	  Statement statement = null;
	  	  ResultSet resultSet = null;
	  	  PreparedStatement pstmt =null; 
	  	 try
	  	  {
	  	  con = DBConnection.createConnection(); //establishing connection
	  	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  	  
	  	   pstmt = con.prepareStatement(sql);
	  	   pstmt.setString(1, bs_name);
	  	   pstmt.setString(2, bs_description);
	  	   pstmt.setString(3, bs_year);
	  	   pstmt.setString(4, bs_id);
	  	   
	  	   pstmt.executeUpdate();
	  	  
	  	
	  	 statement.close();
	  	  }
	  	  catch(SQLException e)
	  	  {
	  	  e.printStackTrace();
	  	  }
	  }   
	  
	  
	  	
	 
	  
	  public String[] getFileID(String userid)
	  { //String sql = "SELECT bs_description FROM brain_storage where s_id ='"+userid+"' order by s_id";
		  String sql = "SELECT bs_id FROM brain_storage where s_id =?  order by s_id";
		  
		  String[] bs_ids;
		  bs_ids = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  PreparedStatement pstmt =null;
		  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  
		  pstmt = con.prepareStatement(sql);
		  pstmt.setString(1,  userid);
		  resultSet= pstmt.executeQuery();
		  
		 // resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  resultSet= pstmt.executeQuery();
		 // resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  bs_ids = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 bs_ids[i] = resultSet.getString("bs_id");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		   e.printStackTrace();
		  }
		 
		  
	    return bs_ids;	
	   }	
	
	  public String getUniversalFieldByID(String bs_id, String field_in_database)
		{
			 String sql = "SELECT "+field_in_database+" FROM brain_storage  where bs_id=? "; 
		      String universal_value=""; 
			  Connection con = null;
			  Statement statement = null;
			  ResultSet resultSet = null;
			  PreparedStatement pstmt =null;
				  
			 try
			  {
			     con = DBConnection.createConnection(); //establishing connection
			     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
			   
			     
			     pstmt = con.prepareStatement(sql);
				 pstmt.setString(1,  bs_id);
				 resultSet= pstmt.executeQuery();
			    // resultSet = statement.executeQuery(sql);
		
			     if (resultSet.next())
			       { 
			    	universal_value= resultSet.getString(field_in_database);
			       }
			     
			 statement.close();
			 
			  } //try
			 	 
			  catch(SQLException e)
			  {
			     e.printStackTrace();
			     System.out.println("Error is --- "+e);
			  }	 
			 
			
			return universal_value;
		}
	  
	
	
	
}
