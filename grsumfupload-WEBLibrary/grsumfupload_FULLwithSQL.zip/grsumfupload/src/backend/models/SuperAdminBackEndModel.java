package backend.models;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
// use DBConnection class from ---mvc.util---
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mvc.util.DBConnection;


public class SuperAdminBackEndModel 
{

	
	
/*
 This function will export  all data from Database to HTMl file 
 * 
 */
 public void ExportToHTML(String path)
	{  
	 // TODO: No good for UTF-8
	 
		
   try {
	   
	//   String AbsolutePath = new File(".").getAbsolutePath();
		File file = new File("c:/publication.html");
		FileWriter fw = new FileWriter(file, false); // true for appending, false for recreate
		PrintWriter pw = new PrintWriter(fw, true ); // true for auto-flush
	/*
	 <!DOCTYPE html>
<html lang="ru">
<head>
<meta charset="windows-1251">	
	 */
		pw.println("<!DOCTYPE html> <html lang='ru-RU'><head><meta charset='windows-1251'><title>��� ���������� ����� �����������</title></head>");
		pw.println("<body>");
		pw.println("<H2></H2>");
		pw.println("��� ���������� "+path);
		pw.println("<table border='1'>");
		
		pw.println("<th>N</th><th>Name</th><th>Description</th><th>Year</th><th>Author</th>");
		
		String[] ids;
		ids = this.getFileID();
		
		String[] names;
		names = this.getNames();
		
		String[] description;
		description = this.getDescription();
		
		String[] year;
		year = this.getYear();
		
		String[] username;
		username = this.getUsernameOfPublication();
		// parameter_name[i] =  new String ( name.getBytes ("iso-8859-1"), "UTF-8");
		
		  for (int i = 0; i < ids.length; i++)
		  {  pw.println("<tr>");
			  pw.println("<td>"+ ids[i]+"</td>" );
			  
			  
			  
			  String name = names[i];
			  byte ptext[] = name.getBytes();
			  String name_value = new String(ptext, "UTF-8"); 
			  
			  
			  
			  pw.println("<td>"+ name_value+"</td>" );
			  pw.println("<td>"+ description[i]+"</td>" );
			  pw.println("<td>"+ year[i]+"</td>" );
			  pw.println("<td>"+ username[i]+"</td>" );
			  pw.println("</tr>");
		  }
		
		  pw.println("</table>");
		  
		pw.println("</body>");
		pw.println("</html>");
		//pw.println(path);
		pw.close();
      }
   catch (Exception e)
                {System.out.println("Error is =  "+e);}
		
	}
 
	public void ExportToCVS(String path)
	{
		 try {
			   
				//   String AbsolutePath = new File(".").getAbsolutePath();
					File file = new File("c:/publication.csv");
					FileWriter fw = new FileWriter(file, false); // true for appending, false for recreate
					PrintWriter pw = new PrintWriter(fw, true); // true for auto-flush
					
				
				//	pw.println("��� ���������� "+path);

					String[] ids;
					ids = this.getFileID();
					
					String[] names;
					names = this.getNames();
					
					String[] description;
					description = this.getDescription();
					
					String[] year;
					year = this.getYear();
					
					String[] username;
					username = this.getUsernameOfPublication();
					// parameter_name[i] =  new String ( name.getBytes ("iso-8859-1"), "UTF-8");
					
					  for (int i = 0; i < ids.length; i++)
					  { 
						  pw.print(ids[i]+";" );
						  
						  pw.print( names[i]+";" );
						  pw.print( description[i]+";" );
						  pw.print( year[i]+";" );
						  pw.print( username[i]+";" );
						  pw.print("\n"); // pw.println();
					  }
					
					 
					//pw.println(path);
					pw.close();
			      }
			   catch (Exception e)
			                {System.out.println("Error is =  "+e);}
	}	
	
	public void ExportToTXT(String path)
	{
		  try {
			   
				//   String AbsolutePath = new File(".").getAbsolutePath();
					File file = new File("c:/publication.txt");
					FileWriter fw = new FileWriter(file, false); // true for appending, false for recreate
					PrintWriter pw = new PrintWriter(fw, true); // true for auto-flush
					
				
					pw.println("��� ���������� "+path);

					String[] ids;
					ids = this.getFileID();
					
					String[] names;
					names = this.getNames();
					
					String[] description;
					description = this.getDescription();
					
					String[] year;
					year = this.getYear();
					
					String[] username;
					username = this.getUsernameOfPublication();
					// parameter_name[i] =  new String ( name.getBytes ("iso-8859-1"), "UTF-8");
					
					  for (int i = 0; i < ids.length; i++)
					  {  pw.println();
						  pw.print(ids[i]+"----" );
						  
						  pw.print( names[i]+"----" );
						  pw.print( description[i]+"----" );
						  pw.print( year[i]+"----" );
						  pw.print( username[i]+"----" );
						  pw.println();
					  }
					
					 
					//pw.println(path);
					pw.close();
			      }
			   catch (Exception e)
			                {System.out.println("Error is =  "+e);}
		
	}
	
/*	
	
	This function delete file from Database by id
*/
	
public void deletePublicationById(String id)
{
   //DELETE FROM brain_storage WHERE bs_id='27'	
	String sql = "DELETE FROM brain_storage WHERE bs_id=?  ";
	/*
	
	conn = setupTheDatabaseConnectionSomehow(); 
    stmt = conn.prepareStatement("INSERT INTO person (name, email) values (?, ?)"); 
     stmt.setString(1, name); 
    stmt.setString(2, email); 
    stmt.executeUpdate();
	*/
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  PreparedStatement pstmt =null; 
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	   /*
	    preparedStatement = dbConnection.prepareStatement(deleteSQL);
			preparedStatement.setInt(1, 1001);

			// execute delete SQL stetement
			preparedStatement.executeUpdate();
	    */
	   pstmt = con.prepareStatement(sql);
	   pstmt.setString(1, id);
	   pstmt.executeUpdate();
	  
	
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
}
	
	
	
	
	
	
	
	
	
	  /*
    Funkciya sobiraet v massiv imena failov- rabot dannogo polzovatelia  
 
 */
 public String[] getfilenames()
 {
	  String sql = "SELECT * FROM brain_storage  order by s_id";
		
	  String[] filenames;
	  filenames = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	 	  
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	  int i=0;
	  int rowcount=0;
	  
	  if(resultSet.last())
     {  rowcount= resultSet.getRow(); } 
	  
	  else 
     {
		  rowcount= 0; //just cus I like to always do some kinda else statement.
     }
	  
	  
	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
	  
	  filenames = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	  
	 while(resultSet.next()) // Until next row is present otherwise it return false
	  {
		 filenames[i] = resultSet.getString("bs_filename");
	    i++;
	  }
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
	 
	  
   return filenames;	
  }
	
	
	
	/*
	 * Function return name of all publications
	 * 
	 * */
	
	  public String[] getNames()
	  {
		  String sql = "SELECT bs_name FROM brain_storage  order by s_id";
		  String[] names;
		  names = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  names = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 names[i] = resultSet.getString("bs_name");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return names;	
	   }
	  
	  
	  
	  /*
	   *  Funkciya sobiraet v massiv description(OPISANIE) vsex rabot   
	  
	  */
	  public String[] getDescription()
	  {
		  String sql = "SELECT bs_description FROM brain_storage  order by s_id";
		  
		  String[] description;
		  description = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  description = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 description[i] = resultSet.getString("bs_description");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return description;	
	   }
	  
	  public String[] getYear()
	  {
		  String sql = "SELECT bs_year FROM brain_storage order by s_id";
		  
		  String[] year;
		  year = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  year = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 year[i] = resultSet.getString("bs_year");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		   e.printStackTrace();
		  }
		 
		  
	    return year;	
	   }	  
	  
	  
	  /*This function get id each file publications*/
	  public String[] getFileID()
	  {
		  String sql = "SELECT bs_id FROM brain_storage order by s_id";
		  
		  String[] bs_ids;
		  bs_ids = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
			  
		  
		  bs_ids = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  {
			 bs_ids[i] = resultSet.getString("bs_id");
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		   e.printStackTrace();
		  }
		 
		  
	    return bs_ids;	
	   }	 
	  
	  /*This function get username each file publications to array*/
	  public String[] getUsernameOfPublication()
	  {
	 	 // String sql = "SELECT bs_year FROM brain_storage order by bs_name";

	 	 String sql = "SELECT a.bs_filename, a.bs_name , b.s_login "+
	 	              "FROM  brain_storage a "+ 
	 	              " INNER JOIN sotrudniki b" +
	 	              " ON a.s_id = b.s_id" +
	 	              " ORDER BY a.s_id";
	 	  
	 	  String[] usernames;
	 	  usernames = new String[1];   // nachalnaya razmernost, kotoraya potom izmenitsia
	 	  Connection con = null;
	 	  Statement statement = null;
	 	  ResultSet resultSet = null;
	 	 	  
	 	 try
	 	  {
	 	  con = DBConnection.createConnection(); //establishing connection
	 	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	 	  int i=0;
	 	  int rowcount=0;
	 	  
	 	  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
	 	  
	 	  else 
	      {
	 		  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
	 	  
	 	  
	 	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	 		  
	 	  
	 	  usernames = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	 	  
	 	 while(resultSet.next()) // Until next row is present otherwise it return false
	 	  {
	 		 usernames[i] = resultSet.getString("b.s_login");
	 	    i++;
	 	  }
	 	 statement.close();
	 	  }
	 	  catch(SQLException e)
	 	  {
	 	  e.printStackTrace();
	 	  }
	 	 
	 	  
	    return usernames;	
	   }


	  
	  /*
	   * method get Info about all kafedra and put in String Array - razdelitel #
	   * 
	   * 
	   * */
	  public String[] getAllKafedra()
	  {
	 	  
	 	  String sql = "SELECT * FROM kafedra   order by k_id";
	 	  String[] allkafedra;
	 	  allkafedra = new String[2];
	 	  Connection con = null;
	 	  Statement statement = null;
	 	  ResultSet resultSet = null;
	 	 	  
	 	 try
	 	  {
	 	  con = DBConnection.createConnection(); //establishing connection
	 	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	 	  int i=0;
	 	  int rowcount=0;
	 	  
	 	  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
	 	  
	 	  else 
	      {
	 		  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
	 	  
	 	  
	 	  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
	 		  
	 	  
	 	  allkafedra = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
	 	  
	 	 while(resultSet.next()) // Until next row is present otherwise it return false
	 	  { 
	 		 
	 		
	 		 String k_id = resultSet.getString("k_id");                
	 		 String k_name= resultSet.getString("k_name");              
	 		 String k_cabinet = resultSet.getString("k_cabinet");           
	 		 String k_email = resultSet.getString("k_email");           
	 		 String k_telefon1 = resultSet.getString("k_telefon1");         
	 		 String k_telefon2 = resultSet.getString("k_telefon2");          
	 		
	 		  
	 		 allkafedra[i] =k_id+"#"+k_name+"#"+k_cabinet+"#"+k_email+"#"+k_telefon1+"#"+k_telefon2;
	 	    i++;
	 	  }
	 	 statement.close();
	 	  }
	 	  catch(SQLException e)
	 	  {
	 	  e.printStackTrace();
	 	  }
	 	 
	 	  
	    return allkafedra;	
	   }  // end of method	  
	  
	  
	  /*
	   * method get Info about all users and put in String Array - razdelitel #
	   * 
	   * 
	   * */
	  public String[] getAllUsersDataByKafedra()
	  {
		  
		  String sql = "SELECT * FROM sotrudniki    order by s_id";
		  	  
		  
		  String[] allusers;
		  allusers = new String[2];
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		 	  
		 try
		  {
		  con = DBConnection.createConnection(); //establishing connection
		  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		  
		 
		  
		  
		  
		  int i=0;
		  int rowcount=0;
		  
		  if(resultSet.last())
	      {  rowcount= resultSet.getRow(); } 
		  
		  else 
	      {
			  rowcount= 0; //just cus I like to always do some kinda else statement.
	      }
		  
		  
		  resultSet = statement.executeQuery(sql); //Here table name is users and userName,password are columns. fetching all the records and storing in a resultSet.
		 
		  
		  allusers = new String[rowcount]; // rashiriaem n apravilnoe kolichestvo
		  
		 while(resultSet.next()) // Until next row is present otherwise it return false
		  { 
			 
			
			 String s_id = resultSet.getString("s_id");            
			  String k_id = resultSet.getString("k_id");                
			 String s_fio= resultSet.getString("s_fio");              
			 String s_rank = resultSet.getString("s_rank");           
			 String s_degree = resultSet.getString("s_degree");           
			 String s_position = resultSet.getString("s_position");         
			 String s_email = resultSet.getString("s_email");          
			 String s_telefon= resultSet.getString("s_telefon");           
			 String s_login = resultSet.getString("s_login");          
			 String s_password = resultSet.getString("s_password");            
			 String s_role = resultSet.getString("s_role");     
			/* 
			 if (s_id!=null)  { }  else {s_id="";}
			 if (k_id!=null)  { }  else {k_id="";}
			 if (s_fio!=null)  { }  else   {s_fio="";}
			 if (s_rank!=null)  { }  else   {s_rank="";}
			 if (s_degree!=null)  { }  else   {s_degree="";}
			 if (s_position!=null) { }  else   {s_position="";}
	 	     if (s_email!=null)  { }  else   {s_email="";}
	 	     if (s_telefon!=null){ }  else   {s_telefon="";}
	 	     if (s_login!=null)  { }  else   {s_login="";}
	 	     if (s_password!=null) { }  else   {s_password="";}
	 	     if (s_role!=null)  { }  else   {s_role="";}
			  */
			 allusers[i] =s_id+"#"+k_id+"#"+s_fio+"#"+s_rank+"#"+s_degree+"#"+s_position+"#"+s_email+"#"+s_telefon+
			 "#"+s_login+"#"+s_password+"#"+s_role;
		    i++;
		  }
		 statement.close();
		  }
		  catch(SQLException e)
		  {
		  e.printStackTrace();
		  }
		 
		  
	    return allusers;	
	   }
	  
/********************************SUPERADMIN UPDATE KAFEDRA PART***************************************************************/	  
	  
	  /*return kafedra name by kafedra ID*/
	  public String getKafedraNameById(String k_id)
	 	{
	 		String kafedra_name=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_name FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 kafedra_name = resultSet.getString("k_name");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_name;
	 	}
	 
	  /*return kafedra cabinet by kafedra ID*/
	  public String getKafedraCabinetById(String k_id)
	 	{
	 		String kafedra_cabinet=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_cabinet FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 kafedra_cabinet = resultSet.getString("k_cabinet");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_cabinet;
	 	}
	  /*return kafedra email by kafedra ID*/
	  public String getKafedraEmailById(String k_id)
	 	{
	 		String kafedra_email=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_email FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 kafedra_email = resultSet.getString("k_email");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_email;
	 	}	
	  /*return kafedra telefon1 by kafedra ID*/
	  public String getKafedraTelefon1ById(String k_id)
	 	{
	 		String kafedra_telefon1=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_telefon1 FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	kafedra_telefon1= resultSet.getString("k_telefon1");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_telefon1;
	 	}	
	  
	  /*return kafedra telefon1 by kafedra ID*/
	  public String getKafedraTelefon2ById(String k_id)
	 	{
	 		String kafedra_telefon2=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_telefon2 FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	kafedra_telefon2= resultSet.getString("k_telefon2");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_telefon2;
	 	}
	  
	public String getUniversalFieldByID(String k_id, String field_in_database)
	{
		String universal_value=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT "+field_in_database+" FROM kafedra  where k_id='" +k_id + "'");
		
		     if (resultSet.next())
		       { 
		    	universal_value= resultSet.getString(field_in_database);
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return universal_value;
	}
	  

	
	/*    UPDATE kafedra SET k_name='��������������� �������, ���������������� ��������� � �������111' , k_cabinet='���. 309 � 221 777', k_email='kaf_matan@grsu.by', k_telefon1='+375-152-74-43-90@', k_telefon2='+375-152-74-43-76%'	WHERE k_id ='1'
		        */
	  
/*	
	
	This function Update Kafedra from Database by kafedra_id
*/
	
public void UpdateKafedraById(String k_id, String k_name,  String k_cabinet, String k_email, String k_telefon1, String k_telefon2)
{
   //DELETE FROM brain_storage WHERE bs_id='27'	
	String sql = "UPDATE kafedra SET k_name=? , k_cabinet=?, k_email=?, k_telefon1=?, k_telefon2=?	WHERE k_id =? ";
	
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  PreparedStatement pstmt =null; 
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  
	   pstmt = con.prepareStatement(sql);
	   pstmt.setString(1, k_name);
	   pstmt.setString(2, k_cabinet);
	   pstmt.setString(3, k_email);
	   pstmt.setString(4, k_telefon1);
	   pstmt.setString(5, k_telefon2);
	   pstmt.setString(6, k_id);
	   
	   pstmt.executeUpdate();
	  
	
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
} 
	  
	
	
}
