package backend.models;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
// use DBConnection class from ---mvc.util---
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mvc.util.DBConnection;

public class SABackEndModelKafedraUpdate 
{
	
	
	/********************************SUPERADMIN UPDATE KAFEDRA PART***************************************************************/	  
	  
	  /*return kafedra name by kafedra ID*/
	  public String getKafedraNameById(String k_id)
	 	{
	 		String kafedra_name=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_name FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 kafedra_name = resultSet.getString("k_name");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_name;
	 	}
	 
	  /*return kafedra cabinet by kafedra ID*/
	  public String getKafedraCabinetById(String k_id)
	 	{
	 		String kafedra_cabinet=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_cabinet FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 kafedra_cabinet = resultSet.getString("k_cabinet");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_cabinet;
	 	}
	  /*return kafedra email by kafedra ID*/
	  public String getKafedraEmailById(String k_id)
	 	{
	 		String kafedra_email=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_email FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	 kafedra_email = resultSet.getString("k_email");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_email;
	 	}	
	  /*return kafedra telefon1 by kafedra ID*/
	  public String getKafedraTelefon1ById(String k_id)
	 	{
	 		String kafedra_telefon1=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_telefon1 FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	kafedra_telefon1= resultSet.getString("k_telefon1");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_telefon1;
	 	}	
	  
	  /*return kafedra telefon1 by kafedra ID*/
	  public String getKafedraTelefon2ById(String k_id)
	 	{
	 		String kafedra_telefon2=""; 
	 		  Connection con = null;
	 		  Statement statement = null;
	 		  ResultSet resultSet = null;
	 		  
	 			  
	 		 try
	 		  {
	 		     con = DBConnection.createConnection(); //establishing connection
	 		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 		     resultSet = statement.executeQuery("SELECT k_telefon2 FROM kafedra  where k_id='" +k_id + "'");
	 		
	 		     if (resultSet.next())
	 		       { 
	 		    	kafedra_telefon2= resultSet.getString("k_telefon2");
	 		       }
	 		     
	 		 statement.close();
	 		 
	 		  } //try
	 		 	 
	 		  catch(SQLException e)
	 		  {
	 		     e.printStackTrace();
	 		     System.out.println("Error is --- "+e);
	 		  }	 
	 		 
	 		
	 		return kafedra_telefon2;
	 	}
	  
	public String getUniversalFieldByID(String k_id, String field_in_database)
	{
		String universal_value=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT "+field_in_database+" FROM kafedra  where k_id='" +k_id + "'");
		
		     if (resultSet.next())
		       { 
		    	universal_value= resultSet.getString(field_in_database);
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return universal_value;
	}
	  

	
	/*    UPDATE kafedra SET k_name='��������������� �������, ���������������� ��������� � �������111' , k_cabinet='���. 309 � 221 777', k_email='kaf_matan@grsu.by', k_telefon1='+375-152-74-43-90@', k_telefon2='+375-152-74-43-76%'	WHERE k_id ='1'
		        */
	  
/*	
	
	This function Update Kafedra from Database by kafedra_id
*/
	
public void UpdateKafedraById(String k_id, String k_name,  String k_cabinet, String k_email, String k_telefon1, String k_telefon2)
{
 //DELETE FROM brain_storage WHERE bs_id='27'	
	String sql = "UPDATE kafedra SET k_name=? , k_cabinet=?, k_email=?, k_telefon1=?, k_telefon2=?	WHERE k_id =? ";
	
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  PreparedStatement pstmt =null; 
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  
	   pstmt = con.prepareStatement(sql);
	   pstmt.setString(1, k_name);
	   pstmt.setString(2, k_cabinet);
	   pstmt.setString(3, k_email);
	   pstmt.setString(4, k_telefon1);
	   pstmt.setString(5, k_telefon2);
	   pstmt.setString(6, k_id);
	   
	   pstmt.executeUpdate();
	  
	
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
} 

}
