package backend.models;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
// use DBConnection class from ---mvc.util---
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mvc.util.DBConnection;

public class SABackEndModelSotrudnikiUpdate 
{

	
	public String getUniversalFieldByID(String s_id, String field_in_database)
	{
		String universal_value=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT "+field_in_database+" FROM sotrudniki  where s_id='" +s_id + "'");
		
		     if (resultSet.next())
		       { 
		    	universal_value= resultSet.getString(field_in_database);
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return universal_value;
	}
	
/*		
	This function Update Sotrudniki from Database by s_id
               
*/
	
public void UpdateSotrudnikiById(String s_id, String k_id, String s_fio,String s_rank,String s_degree,String s_position,String s_email,String s_telefon,String s_login,String s_password,String s_role)
{
 //DELETE FROM brain_storage WHERE bs_id='27'	
	String sql = "UPDATE sotrudniki SET k_id=? , s_fio=?, s_rank=?, s_degree=?, s_position=?, s_email=?, s_telefon=?, s_login=?, s_password=?, s_role=?	WHERE s_id =? ";
	
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  PreparedStatement pstmt =null; 
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  
	   pstmt = con.prepareStatement(sql);
	   pstmt.setString(1,  k_id);
	   pstmt.setString(2,  s_fio);
	   pstmt.setString(3,  s_rank);
	   pstmt.setString(4,  s_degree);
	   pstmt.setString(5,  s_position);
	   pstmt.setString(6, s_email);
	   pstmt.setString(7,s_telefon);
	   pstmt.setString(8, s_login);
	   pstmt.setString(9, s_password);
	   pstmt.setString(10,s_role);
	   
	   pstmt.setString(11,  s_id);	   
	   pstmt.executeUpdate();
	  
	
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
} 

/*		
This function Update Sotrudniki from Database by s_id
           
*/

public void InsertSotrudniki(String k_id, String s_fio,String s_rank,String s_degree,String s_position,String s_email,String s_telefon,String s_login,String s_password,String s_role)
{
	
String sql = "INSERT INTO sotrudniki"+ 
   "(       k_id, s_fio,s_rank,s_degree,s_position,s_email, s_telefon, s_login, s_password,s_role)"+
   "VALUES (?,     ? ,     ? ,       ? ,      ?,       ?,        ?,       ?,         ? ,    ?) ";

  Connection con = null;
  Statement statement = null;
  ResultSet resultSet = null;
  PreparedStatement pstmt =null; 
 try
  {
  con = DBConnection.createConnection(); //establishing connection
  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
  
   pstmt = con.prepareStatement(sql);
   pstmt.setString(1,  k_id);
   pstmt.setString(2,  s_fio);
   pstmt.setString(3,  s_rank);
   pstmt.setString(4,  s_degree);
   pstmt.setString(5,  s_position);
   pstmt.setString(6, s_email);
   pstmt.setString(7,s_telefon);
   pstmt.setString(8, s_login);
   pstmt.setString(9, s_password);
   pstmt.setString(10,s_role);   
  	   
   pstmt.executeUpdate();
  

 statement.close();
  }
  catch(SQLException e)
  {
  e.printStackTrace();
  }
}

/*	

	This function delete file from Database by id
*/ 
public void deleteSotrudnikiById(String id)
{
   //DELETE FROM brain_storage WHERE bs_id='27'	
	String sql = "DELETE FROM sotrudniki WHERE s_id=?  ";

	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  PreparedStatement pstmt =null; 
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	 
	   pstmt = con.prepareStatement(sql);
	   pstmt.setString(1, id);
	   pstmt.executeUpdate();
	  
	
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
}

	
	
}
