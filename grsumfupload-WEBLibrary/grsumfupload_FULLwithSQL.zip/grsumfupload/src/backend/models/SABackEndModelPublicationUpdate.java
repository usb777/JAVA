package backend.models;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
// use DBConnection class from ---mvc.util---
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import mvc.util.DBConnection;

public class SABackEndModelPublicationUpdate 
{

	
	public String getUniversalFieldByID(String bs_id, String field_in_database)
	{
		String universal_value=""; 
		  Connection con = null;
		  Statement statement = null;
		  ResultSet resultSet = null;
		  
			  
		 try
		  {
		     con = DBConnection.createConnection(); //establishing connection
		     statement = con.createStatement(); //Statement is used to write queries. Read more about it.
		     resultSet = statement.executeQuery("SELECT "+field_in_database+" FROM brain_storage  where bs_id='" +bs_id + "'");
		
		     if (resultSet.next())
		       { 
		    	universal_value= resultSet.getString(field_in_database);
		       }
		     
		 statement.close();
		 
		  } //try
		 	 
		  catch(SQLException e)
		  {
		     e.printStackTrace();
		     System.out.println("Error is --- "+e);
		  }	 
		 
		
		return universal_value;
	}

/*	
	
	This function Update Publication from Database by bs_id
	
	
*/
	
public void UpdatePublicationById(String bs_id, String bs_name,  String bs_description, String bs_year)
{
 //DELETE FROM brain_storage WHERE bs_id='27'	
	String sql = "UPDATE brain_storage SET bs_name=? , bs_description=?, bs_year=?	WHERE bs_id =? ";
	
	  Connection con = null;
	  Statement statement = null;
	  ResultSet resultSet = null;
	  PreparedStatement pstmt =null; 
	 try
	  {
	  con = DBConnection.createConnection(); //establishing connection
	  statement = con.createStatement(); //Statement is used to write queries. Read more about it.
	  
	   pstmt = con.prepareStatement(sql);
	   pstmt.setString(1, bs_name);
	   pstmt.setString(2, bs_description);
	   pstmt.setString(3, bs_year);
	   pstmt.setString(4, bs_id);
	   
	   pstmt.executeUpdate();
	  
	
	 statement.close();
	  }
	  catch(SQLException e)
	  {
	  e.printStackTrace();
	  }
} 

	
}
