package backend.controllers;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import backend.models.ModelUploader;

import com.oreilly.servlet.MultipartRequest;  //   cos.jar
//   cos.jar
/**
 * Servlet implementation class ControllerBackEndUploadFiles
 */
@WebServlet("/ControllerBackEndUploader")
public class ControllerBackEndUploader extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	
	 private static final String SAVE_DIR = "AllUsersDocs"; // upload dirrectory for All users	
	
	
	
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerBackEndUploader() {
        super();
        // TODO Auto-generated constructor stub
    }
    
    



	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
	}
	
	
/* 
 * Funckciya directoryCreateAndExist
 * Proverka na sushestvoavnie direktorii dlia pozlovatelia i eio sozdanie, esli otsutsvuet
 */	
	  private void directoryCreateAndExist(String path)
	  {  
		  
		  File filed = new File(path);
	        if(!filed.exists())
	        {  if(filed.mkdir())
	          { System.out.println("directory is created"); }
	        } 
	           else{ System.out.println("directory exist");  }
	  }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
			
		HttpSession session = request.getSession(true); 
		 PrintWriter out = response.getWriter();
	      
	      
	      
	      
	      String report="";  // peremennaya dlia sozdaniya otchiota i peredachi eio na -backendUploader.jsp-
	       
		    try {
		      // Blindly take it on faith this is a multipart/form-data request

		      // Construct a MultipartRequest to help read the information.
		      // Pass in the request, a directory to save files to, and the
		      // maximum POST size we should attempt to handle.
		      // Here we (rudely) write to /tmp and impose a 50 K limit.
		    	
		    	
		    	
		    	  String appPath = request.getServletContext().getRealPath("");
		    	  
		    	  // constructs path of the directory to save uploaded file
		    	  String savePathAllUsersDocs = appPath + File.separator + SAVE_DIR;
			      
		    	  
		    	  String savePath = appPath + File.separator + SAVE_DIR + File.separator +session.getAttribute("username");
			      
			     
		          //!!!!!!!!! don't forget create Uploaded directory
		          directoryCreateAndExist(savePathAllUsersDocs); // Proverka sushestvovaniya  -AllUsersDocs- directory i sozdanie
		          directoryCreateAndExist(savePath); // Proverka sushestvovaniya  - v AllUsersDocs directorii polzovatelia
		         
		          
	   MultipartRequest multi =    new MultipartRequest(request, savePath, 50 *1024 * 1024,   new com.oreilly.servlet.multipart.DefaultFileRenamePolicy());

		      
		      report+= "<H1>Файл успешно загружен  на сервер</H1>";

		      // Print the parameters we received
		      report+=("<H3>Params:</H3>");
		      report+=("<PRE>");
		      Enumeration params = multi.getParameterNames();
		      
		      String[] parameter_name;
		      parameter_name = new String[6];
		      String[] parameter_value;
		      parameter_value = new String[6];
		      String filename_for_database ="";
		      int i=0;
		   //   new String (s.getBytes ("iso-8859-1"), "UTF-8");
		    		      
		      
		      while (params.hasMoreElements()) 
		      { 
		        String name = (String)params.nextElement();
		        String value = multi.getParameter(name);
		        
		        parameter_name[i] =  new String ( name.getBytes ("iso-8859-1"), "UTF-8"); // perebivaem v chitaemuu kodirovku
		        parameter_value[i] = new String ( value.getBytes ("iso-8859-1"), "UTF-8");
		        
		         report+=(parameter_name[i] + " = " + parameter_value[i]+"<br>");
		        /* 
		         parameter_name[i] = name;
		         parameter_value[i] = value;
		         */
		        // parameter_name[i] =  new String ( name.getBytes ("iso-8859-1"), "UTF-8"); // 
		        // parameter_value[i] = new String ( value.getBytes ("iso-8859-1"), "UTF-8");
		         
		         
		         System.out.println("parameter_name["+i+"]="+ parameter_name[i]+"  value["+i+"]="+ parameter_value[i]);
			      i++;
		      }
		      /*
		       <pre>
                 b_description = ÐÐ²ÐµÐ´Ð¸ÑÐµ Ð¾Ð¿Ð¸ÑÐ°Ð½Ð¸Ðµ:asdasd
                            <br/>
                 b_name = 1996
                  <br/>
                 b_year = 2011
                 <br/>
                  submUploader = ÐÐ°Ð³ÑÑÐ·Ð¸ÑÑ ÑÐ°Ð¹Ð»
                  <br/>
                    HI!
                </pre>
		       * */
		     
		      
		       report+=("</PRE>");

		      // Show which files we received
		       report+=("<H3>Files:</H3>");
		       report+=("<PRE>");
		      Enumeration files = multi.getFileNames();
		      
		      String uploadedfilename="";
		      while (files.hasMoreElements()) 
		      {
		        String name = (String)files.nextElement();
		        
		        String filename = multi.getFilesystemName(name);
		        
		        String original = multi.getOriginalFileName(name);
		        String type = multi.getContentType(name);
		        File f = multi.getFile(name);
		         report+=("name: " + name+"<br>");
		         report+=("filename: " + filename+"<br>");
		        if (filename != null && !filename.equals(original)) 
		         {
		           report+=("original file name: " + original+"<br>");
		         } //if
		         report+=("type: " + type+"<br>");
		        if (f != null) 
		        {
		        	report+=("length: " + f.length())+"<br>";
		        }
		        report+="</br></br>";
		        uploadedfilename = original;
		       
		        filename_for_database = new String ( filename.getBytes ("iso-8859-1"), "UTF-8");  // take filename from cikl for Database
		              
		      } //while
		       report+=("</PRE>");
		       
		       
		       request.setAttribute("file_full_url",File.separator+savePath+ File.separator + uploadedfilename);
		       request.setAttribute("file_short_url","grsumfupload"+ File.separator+SAVE_DIR+ File.separator +session.getAttribute("username")+ File.separator +uploadedfilename);
		    
		       
		    // Zdes proishodit dobavlenie zapisei o faile v bazu dannyx   
		       
		       ModelUploader muploader = new ModelUploader();
		       try {
		    	 
		     	  System.out.println(request.getParameter("b_name")+"<br>");
		    	  System.out.println(request.getParameter("b_description")+"<br>");
		    	  System.out.println(request.getParameter("b_year")+"<br>");
		    	    muploader.insertDocsByUser(muploader.getUserId(session.getAttribute("username").toString()), request.getAttribute("file_full_url").toString(),
		    	    		parameter_value[1], parameter_value[0], parameter_value[2], filename_for_database);
		 		  //  muploader.insertDocsByUser("1", "2", "3", "4", "5");
			       /* 
		       
		       parameter_name[0]=b_description  value[0]=?????µ???????µ ?????????°?????µ:??????????????????
               parameter_name[1]=b_name  value[1]=???????????°
               parameter_name[2]=b_year  value[2]=1996
                parameter_name[3]=submUploader  value[3]=???°???????·?????? ???°???»
		       */
		       }
		       catch (Exception e)
		       { System.out.println("Error is - "+e);}
		       
		       
		       
		    } //try
		    catch (Exception e) 
		     {
		       report+=("<PRE>");
		      e.printStackTrace(out);
		       report+=("-------------ERROR is------------------"+e);
		       report+=("</PRE>");
		     }// catch
		    
		    request.setAttribute("report", report); 
		 
			 RequestDispatcher backendUploadJsp = request.getRequestDispatcher("backendUploader.jsp");
			 backendUploadJsp.forward(request, response);
		    
		   // out.println("</BODY></HTML>");
		    
		    /*
		    
<HTML>
<HEAD><TITLE>UploadTest</TITLE></HEAD>
<BODY>
<H1>UploadTest</H1>
<H3>Params:</H3>
<PRE>
b_description = Ð’Ð²ÐµÐ´Ð¸Ñ‚Ðµ Ð¾Ð¿Ð¸ÑÐ°Ð½Ð¸Ðµ:
b_name = 
b_year = 
</PRE>
<H3>Files:</H3>
<PRE>
name: file
filename: grsumfupload.doc
type: application/msword
length: 4016099

</PRE>
</BODY></HTML>

		    */
	}

	

	
	

}
