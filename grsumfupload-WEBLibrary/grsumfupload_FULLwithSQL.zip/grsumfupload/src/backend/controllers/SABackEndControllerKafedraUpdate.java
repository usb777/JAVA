package backend.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import backend.models.SABackEndModelKafedraUpdate;

/**
 * Servlet implementation class SuperAdminBackEndControllerKafedraUpdate
 */
@WebServlet("/SABackEndControllerKafedraUpdate")
public class SABackEndControllerKafedraUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SABackEndControllerKafedraUpdate() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		
		if (request.getParameter("subm").equals("���������")) // knopka Submit - najata
		  {
			  	
		try{
			 String k_id=           request.getParameter("k_id");
			 String k_name=         request.getParameter("k_name"); 
			 String k_cabinet=      request.getParameter("k_cabinet");
			 String k_email=        request.getParameter("k_email");
			 String k_telefon1=     request.getParameter("k_telefon1");
			 String k_telefon2=     request.getParameter("k_telefon2");
			 
			 
			 
		    this.UpdateKafedraByIdFromModel(k_id, k_name, k_cabinet, k_email, k_telefon1, k_telefon2);
		  }
		catch(Exception e)
		    {System.out.println("Error is - "+e);} 
		    
	  	 }
		 else 
		 {
			 
		 }
		 
		 request.getRequestDispatcher("backendSuperAdminKafedra.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	
	/*return kafedra universal value from Model*/
	public String getKafedraUniversalValueFromModel(String k_id, String field_database)
	 {  String uniValue="";
	 SABackEndModelKafedraUpdate sabemku = new SABackEndModelKafedraUpdate();
		uniValue = sabemku.getUniversalFieldByID(k_id,field_database);
	 return uniValue;
	 }
	
	
	/*
	update kafedra by id
	* */
	public void UpdateKafedraByIdFromModel(String k_id, String k_name,  String k_cabinet, String k_email, String k_telefon1, String k_telefon2)
	{
		 SABackEndModelKafedraUpdate sabemku = new SABackEndModelKafedraUpdate();
	     sabemku.UpdateKafedraById(k_id, k_name, k_cabinet, k_email, k_telefon1, k_telefon2);

	}

	
	

}
