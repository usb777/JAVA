package backend.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



import backend.models.SABackEndModelPublicationUpdate;

/**
 * Servlet implementation class SuperAdminBackEndControllerAllPublication
 */
@WebServlet("/SABackEndControllerPublicationUpdate")
public class SABackEndControllerPublicationUpdate extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SABackEndControllerPublicationUpdate() 
    {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		if (request.getParameter("subm").equals("���������")) // knopka Submit - najata
		  {
			  	
		try{
			 String bs_id=           request.getParameter("bs_id");
			 String bs_name=         request.getParameter("bs_name"); 
			 String bs_description=      request.getParameter("bs_description");
			 String bs_year=        request.getParameter("bs_year");
			
			 
		    this.UpdatePublicationByIdFromModel(bs_id, bs_name, bs_description, bs_year);
		  }
		catch(Exception e)
		    {System.out.println("Error is - "+e);} 
		    
	  	 }
		 else 
		 {
			 
		 }
		 
		 request.getRequestDispatcher("backendSuperAdmin.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	
	/*return kafedraemail by kafedra ID from Model*/
	public String getPublicationUniversalValueFromModel(String bs_id, String field_database)
	 {  String uniValue="";
	    SABackEndModelPublicationUpdate sabemap = new SABackEndModelPublicationUpdate();
		uniValue = sabemap.getUniversalFieldByID(bs_id,field_database);
	 return uniValue;
	 }
	
	/*
	update kafedra by id
	* */
	public void UpdatePublicationByIdFromModel(String bs_id, String bs_name,  String bs_description, String bs_year)
	{
		SABackEndModelPublicationUpdate sabempu = new SABackEndModelPublicationUpdate();
	     sabempu.UpdatePublicationById(bs_id, bs_name, bs_description, bs_year);

	}
		
	

}
