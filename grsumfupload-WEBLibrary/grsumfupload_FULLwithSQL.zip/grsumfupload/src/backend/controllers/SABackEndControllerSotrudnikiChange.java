package backend.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;






import backend.models.ModelBackEndMain;
import backend.models.SABackEndModelSotrudnikiUpdate;

/**
 * Servlet implementation class SuperAdminBackEndControllerSotrudnikiUpdate
 */
@WebServlet("/SABackEndControllerSotrudnikiChange")
public class SABackEndControllerSotrudnikiChange extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SABackEndControllerSotrudnikiChange() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		/******DELETE USER******/
		 if ( request.getParameter("action").equals("delete")   )
		 {
		    // this.deletePublicationById(request.getParameter("bs_id"));
			 String s_id = request.getParameter("s_id");
			 this.deleteSotrudnikiById(s_id);
	  	 }
		 else 
		 {
			

		 }
		 /******INSERT USER******/
		 if ( request.getParameter("action").equals("insert")   )
		 {	
		
		if (request.getParameter("subm").equals("���������")) // knopka Submit - najata
		  {
			  	
		    try
		    {
			
			
			 String k_id =     request.getParameter("k_id"); //get kafedra name for input text
             String s_fio =  request.getParameter("s_fio");
             String s_rank =   request.getParameter("s_rank");
             String s_degree = request.getParameter("s_degree");
             String s_position = request.getParameter("s_position");    
             String s_email = request.getParameter("s_email");
             String s_telefon = request.getParameter("s_telefon");
             String s_login = request.getParameter("s_login");
             String s_password =request.getParameter("s_password");
             String s_role = request.getParameter("s_role");
			 
			 
		     this.InsertSotrudnikiByIdFromModel(k_id, s_fio, s_rank, s_degree, s_position, s_email, s_telefon, s_login, s_password, s_role);
		   } //try
		catch(Exception e)
		    {System.out.println("Error is - "+e);} 
		    
	  	 } // if subm
		
		 } // action
		 
		 /******DELETE USER******/
		 if ( request.getParameter("action").equals("update")   )
		 {	
		
				if (request.getParameter("subm").equals("���������")) // knopka Submit - najata
				  {
					  	
				try{
					
					
					 String s_id =     request.getParameter("s_id"); //get s_id for input text
					 String k_id =     request.getParameter("k_id"); //get kafedra name for input text
		             String s_fio =  request.getParameter("s_fio");
		             String s_rank =   request.getParameter("s_rank");
		             String s_degree = request.getParameter("s_degree");
		             String s_position = request.getParameter("s_position");    
		             String s_email = request.getParameter("s_email");
		             String s_telefon = request.getParameter("s_telefon");
		             String s_login = request.getParameter("s_login");
		             String s_password =request.getParameter("s_password");
		             String s_role = request.getParameter("s_role");
					 
					 
				    this.UpdateSotrudnikiByIdFromModel(s_id, k_id, s_fio, s_rank, s_degree, s_position, s_email, s_telefon, s_login, s_password, s_role);
				  }
				catch(Exception e)
				    {System.out.println("Error is - "+e);} 
				    
			  	 }
		
		 } // action
		 
		 /*************/
		 
		 
		 
		 
		 else 
		 {
			 
		 }
		 
		 request.getRequestDispatcher("backendSuperAdminUsers.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		// TODO Auto-generated method stub
	}
	
	/*return sotrudniki universal value from Model*/
	public String getSotrudnikiUniversalValueFromModel(String s_id, String field_database)
	 {  String uniValue="";
	 SABackEndModelSotrudnikiUpdate sabemsu = new SABackEndModelSotrudnikiUpdate();
		uniValue = sabemsu.getUniversalFieldByID(s_id,field_database);
	 return uniValue;
	 }
	
	/*
	update sotrudniki by id
	* */
	public void InsertSotrudnikiByIdFromModel(String k_id, String s_fio,String s_rank,String s_degree,String s_position,String s_email,String s_telefon,String s_login,String s_password,String s_role)
	{
		SABackEndModelSotrudnikiUpdate sabemsu = new SABackEndModelSotrudnikiUpdate();
	    sabemsu.InsertSotrudniki(k_id, s_fio, s_rank, s_degree, s_position, s_email, s_telefon, s_login, s_password, s_role);
	}
	
	public void deleteSotrudnikiById(String s_id)
	{
		
		SABackEndModelSotrudnikiUpdate sdelete = new SABackEndModelSotrudnikiUpdate();
		sdelete.deleteSotrudnikiById(s_id);
	}
	
	/*
	update sotrudniki by id
	* */
	public void UpdateSotrudnikiByIdFromModel(String s_id, String k_id, String s_fio,String s_rank,String s_degree,String s_position,String s_email,String s_telefon,String s_login,String s_password,String s_role)
	{
		SABackEndModelSotrudnikiUpdate sabemsu = new SABackEndModelSotrudnikiUpdate();
	    sabemsu.UpdateSotrudnikiById(s_id, k_id, s_fio, s_rank, s_degree, s_position, s_email, s_telefon, s_login, s_password, s_role);

	}
	
	
	

}
