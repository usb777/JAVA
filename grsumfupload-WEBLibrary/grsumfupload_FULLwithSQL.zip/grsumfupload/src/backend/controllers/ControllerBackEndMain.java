package backend.controllers;

import java.io.File;
import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import backend.models.ModelBackEndMain;

/**
 * Servlet implementation class ControllerBackEndMain
 */
@WebServlet("/ControllerBackEndMain")
public class ControllerBackEndMain extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerBackEndMain() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		/*
		
		int id = 0;
		ModelBackEndMain mbem = new ModelBackEndMain();
		id = mbem.getUserId(session.getAttribute("username").toString());
		
		this.setUserID(id);
		*/
		HttpSession session = request.getSession(true);
		// TODO Auto-generated method stub
				 if ( request.getParameter("action").equals("delete")   )
				 {
				    
				     
				      String path = request.getContextPath();
				      
				      String username = session.getAttribute("username").toString();
				      String bs_id= request.getParameter("bs_id");
				    //  path+"/AllUsersDocs/"+username+"/"+fnames[i]
				    	String filename = this.getPublicationUniversalValueFromModel(bs_id, "bs_filename")	;
				    	
				        String fullpath=path+"/AllUsersDocs/"+username+"/" +filename;	
				    	
				        System.out.println("**********Fullpath ==="+fullpath);     
				 File deleteFile = new File(fullpath) ;
				
				  // check if the file  present or not
				  if( deleteFile.exists() )
				  deleteFile.delete() ;
				  
				  this.deletePublicationById(request.getParameter("bs_id")); 
			  	 }
				 
				 if ( request.getParameter("action").equals("update")   )
				 {
				     //this.deletePublicationById(request.getParameter("bs_id"));
					// this.UpdatePublicationByIdFromModel(bs_id, bs_name, bs_description, bs_year);
					 if (request.getParameter("subm").equals("���������")) // knopka Submit - najata
					  {
						  	
					try{
						 String bs_id=           request.getParameter("bs_id");
						 String bs_name=         request.getParameter("bs_name"); 
						 String bs_description=      request.getParameter("bs_description");
						 String bs_year=        request.getParameter("bs_year");
						
						 
					    this.UpdatePublicationByIdFromModel(bs_id, bs_name, bs_description, bs_year);
					  }
					catch(Exception e)
					    {System.out.println("Error is - "+e);} 
					    
				  	 }
					 else 
					 {
						 
					 }
					 
			  	 }  // update
				 
				 else 
				 {
					

				 }
				
				 request.getRequestDispatcher("backend.jsp").forward(request, response);
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}
	
	
// Vozvrashaet ID polzovatelia po ego Login	
public int getUseridFromModel (String username)  
  {   int userid=0;
      ModelBackEndMain mbem = new ModelBackEndMain();
	userid = mbem.getUserId(username);
     return userid;
  }

//Sobiraet v massiv nazvanie Failov publikacij konkretnogo polzovatelia
public String[] getFilenamesFromModel (String username)  
{ 
	 String[] filenames;
	 int userid=0;
     ModelBackEndMain mbem = new ModelBackEndMain();
	 userid = mbem.getUserId(username); 
    filenames = mbem.getfilenames(userid);
	
    return filenames;
	
}

//Sobiraet v massiv Imena publikacij konkretnogo polzovatelia
public String[] getNamesFromModel (String username)  
{ 
	 String[] names;
	 int userid=0;
     ModelBackEndMain mbem = new ModelBackEndMain();
	 userid = mbem.getUserId(username); 
    names = mbem.getNames(userid);
	
    return names;
	
}

//Sobiraet v massiv Opisaniya rabot publikacij konkretnogo polzovatelia
public String[] getDescriptionFromModel (String username)  
{ 
	 String[] description;
	 int userid=0;
     ModelBackEndMain mbem = new ModelBackEndMain();
	 userid = mbem.getUserId(username); 
    description = mbem.getDescription(userid);
	
    return description;
	
}

// Sobiraet v massiv goda publikacij konkretnogo polzovatelia
public String[] getYearFromModel (String username)  
{ 
	 String[] year;
	 int userid=0;
     ModelBackEndMain mbem = new ModelBackEndMain();
	 userid = mbem.getUserId(username); 
    year = mbem.getYear(userid);
	
    return year;
	
}



/* vozvrashaet vse id failov v massiv iz brain _storage*/
public String[] getFileIDSFromModel(String userid)  
{ 
	 String[] ids;
	 ModelBackEndMain mbem = new ModelBackEndMain();
	 
    ids = mbem.getFileID(userid);
	
    return ids;
	
}

public void deletePublicationById(String id)
{
	
	ModelBackEndMain mbem = new ModelBackEndMain();
	mbem.deletePublicationById(id);
}

/*return kafedraemail by kafedra ID from Model*/
public String getPublicationUniversalValueFromModel(String bs_id, String field_database)
 {  String uniValue="";
    ModelBackEndMain mbem = new ModelBackEndMain();
	uniValue =  mbem.getUniversalFieldByID(bs_id,field_database);
 return uniValue;
 }

/*
update kafedra by id
* */
public void UpdatePublicationByIdFromModel(String bs_id, String bs_name,  String bs_description, String bs_year)
{
	ModelBackEndMain mbem = new ModelBackEndMain();
	mbem.UpdatePublicationById(bs_id, bs_name, bs_description, bs_year);

}
	





}