package backend.controllers;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import frontend.models.ModelFrontEndMain;
import backend.models.ModelBackEndMain;
import backend.models.SuperAdminBackEndModel;

/**
 * Servlet implementation class SuperadminBackEndController
 */
@WebServlet("/SuperadminBackEndController")
public class SuperadminBackEndController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SuperadminBackEndController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		 if ( request.getParameter("action").equals("delete")   )
		 {
		     this.deletePublicationById(request.getParameter("bs_id"));
	  	 }
		 else 
		 {
			
		 }
		 request.getRequestDispatcher("backendSuperAdmin.jsp").forward(request, response);
		 
		
	}
	
	
/*
	 delete publication by id
 * */
public void deletePublicationById(String id)
{
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	sabem.deletePublicationById(id);
	
}




	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		
		SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
		//sabem.deletePublicationById("26");
		
		/*
		 if ( request.getParameter("action")!="delete"   )
		 {
			// request.setAttribute("action1", "delete this"); 
		//	this.deletePublicationById(request.getParameter("bs_id"));
			
			
		 }
		 else 
		 {
			

		 }
		*/
		
		
		 if (request.getParameter("button1") != null) 
		  {
	           // ExportToHtml();
			 
			 sabem.ExportToHTML(request.getParameter("path_webapps"));
		       request.setAttribute("action_is","�������������� � HTML" );
		       
		       } 
		 else if (request.getParameter("button2") != null) 
	       {
			 // ExportToCVS();
			 sabem.ExportToCVS(request.getParameter("path_webapps"));
		       request.setAttribute("action_is","�������������� � CVS" );
	        }
		 else if (request.getParameter("button3") != null) 
	        {
			      // ExportToTXT();
			    sabem.ExportToTXT(request.getParameter("path_webapps"));
		       request.setAttribute("action_is","�������������� � TXT" );
	        }
 		 else {
	            // ???
	        }
             
	        request.getRequestDispatcher("backendSuperAdmin.jsp").forward(request, response);
		
		
	} // doPOST
	
	public String[] getFilenamesFromModel ()  
	{ 
		 String[] filenames;
		 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
		 
	    filenames = sabem.getfilenames();
		
	    return filenames;
		
	}
	
	public String[] getNamesFromModel ()  
	{ 
		 String[] names;
		
		 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
		
	    names = sabem.getNames();
		
	    return names;
		
	}
	
	//Sobiraet v massiv Opisaniya rabot publikacij konkretnogo polzovatelia
	public String[] getDescriptionFromModel ()  
	{ 
		 String[] description;
		
		 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
		 
	    description = sabem.getDescription();
		
	    return description;
		
	}

	// Sobiraet v massiv goda publikacij konkretnogo polzovatelia
	public String[] getYearFromModel ()  
	{ 
		 String[] year;
		 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
		 
	    year = sabem.getYear();
		
	    return year;
		
	}
	
	/* vozvrashaet vse id failov v massiv iz brain _storage*/
	public String[] getFileIDSFromModel()  
	{ 
		 String[] ids;
		 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
		 
	    ids = sabem.getFileID();
		
	    return ids;
		
	}



/*
 * Controller function return all  kafedra data
 * 
 * */
public String[] getAllKafedraFromModel()  
{ 
	 String[] allkafedra;		
	 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	 
     allkafedra = sabem.getAllKafedra();
    return allkafedra;		
}	

/*
 * Controller function return all  kafedra data
 * 
 * */
public String[] getAllUsersFromModel()  
{ 
	 String[] allusers;		
	 SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	 
     allusers = sabem.getAllUsersDataByKafedra();
    return allusers;		
}


/********************************SUPERADMIN UPDATE KAFEDRA PART***************************************************************/	
/*return kafedra name by kafedra ID from Model*/
public String getKafedraNameFromModel(String k_id)
 {  String k_name="";
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	k_name = sabem.getKafedraNameById(k_id);
 return k_name;
 }

/*return kafedracabinet by kafedra ID from Model*/
public String getKafedraCabinetFromModel(String k_id)
 {  String k_cabinet="";
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	k_cabinet = sabem.getKafedraCabinetById(k_id);
 return k_cabinet;
 }

/*return kafedraemail by kafedra ID from Model*/
public String getKafedraEmailFromModel(String k_id)
 {  String k_email="";
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	k_email = sabem.getKafedraEmailById(k_id);
 return k_email;
 }

/*return kafedraemail by kafedra ID from Model*/
public String getKafedraTelefon1FromModel(String k_id)
 {  String k_tel1="";
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	k_tel1 = sabem.getKafedraTelefon1ById(k_id);
 return k_tel1;
 }


/*return kafedraemail by kafedra ID from Model*/
public String getKafedraTelefon2FromModel(String k_id)
 {  String k_tel2="";
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	k_tel2 = sabem.getKafedraTelefon2ById(k_id);
 return k_tel2;
 }


/*return kafedraemail by kafedra ID from Model*/
public String getKafedraUniversalValueFromModel(String k_id, String field_database)
 {  String uniValue="";
	SuperAdminBackEndModel sabem = new SuperAdminBackEndModel();
	uniValue = sabem.getUniversalFieldByID(k_id,field_database);
 return uniValue;
 }

	

}
