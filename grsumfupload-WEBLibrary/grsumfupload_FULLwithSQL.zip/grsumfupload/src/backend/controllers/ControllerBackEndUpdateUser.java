package backend.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import backend.models.ModelUpdateUserData;;

/**
 * Servlet implementation class ControllerBackEndUpdateUser
 */
@WebServlet("/ControllerBackEndUpdateUser")
public class ControllerBackEndUpdateUser extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ControllerBackEndUpdateUser() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
		response.setContentType("text/html; charset=UTF-8");
		response.setCharacterEncoding("UTF-8");
		HttpSession session = request.getSession(true); 
		
		
		
		ModelUpdateUserData muud =new  ModelUpdateUserData();
		String[] all_user_data;
	
		/*
		all_user_data =muud.returnAllUserDataStringArray(session.getAttribute("username").toString());
		
		// TODO: setAttribute by ARRAY
		request.setAttribute("k_id",  all_user_data[0] );
		request.setAttribute("s_fio",  all_user_data[1] );
		request.setAttribute("s_rank",  all_user_data[2] );
		request.setAttribute("s_degree",  all_user_data[3] );
		request.setAttribute("s_position",  all_user_data[4] );
		request.setAttribute("s_email",  all_user_data[5] );
		request.setAttribute("s_telefon",  all_user_data[6] );
		request.setAttribute("s_login",  all_user_data[7] );
		request.setAttribute("s_password",  all_user_data[8] );
		request.setAttribute("k_name",  all_user_data[9] );
		 */
  
    System.out.println();
    try{ 
		  if (request.getParameter("subm").equals("submited")) // knopka Submit - najata
		  {
			  	
				try{  //muud.getKafedraIdByKafedraName(request.getParameter("k_name"))
				     // TODO:  KAFEDRY poka tolko  "1" - sdelat normalnyj UPdate
					muud.updateUserData(session.getAttribute("username").toString(), request.getParameter("k_id"), request.getParameter("s_fio"), request.getParameter("s_rank"), 
					request.getParameter("s_degree"), request.getParameter("s_position"), request.getParameter("s_email"), request.getParameter("s_telefon"), request.getParameter("s_password"));
					
					request.setAttribute("report", "������ ���������!"); // posylaem soobschenie v backendUpdateUser.jsp
					
				}
				catch(Exception e)
				{System.out.println("Error is - "+e);}
				
		  }
		  else {   }  // ne najata  
			   
		    
		 } 
		 catch (Exception e)
		  {
			 System.out.println("------Error is ------------"+e+"-------123--------"); 
		  }
		
    
    all_user_data =muud.returnAllUserDataStringArray(session.getAttribute("username").toString());
	
 // TODO: setAttribute by ARRAY
	request.setAttribute("k_id",  all_user_data[0] );
	request.setAttribute("s_fio",  all_user_data[1] );
	request.setAttribute("s_rank",  all_user_data[2] );
	request.setAttribute("s_degree",  all_user_data[3] );
	request.setAttribute("s_position",  all_user_data[4] );
	request.setAttribute("s_email",  all_user_data[5] );
	request.setAttribute("s_telefon",  all_user_data[6] );
	request.setAttribute("s_login",  all_user_data[7] );
	request.setAttribute("s_password",  all_user_data[8] );
	request.setAttribute("k_name",  all_user_data[9] );
    
    
    
   
			
			RequestDispatcher backendUpdateUser = request.getRequestDispatcher("backendUpdateUser.jsp");
			 backendUpdateUser.forward(request, response);	
			
		 
	} // end of  this.doGet

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		// TODO Auto-generated method stub
	
	}

}
